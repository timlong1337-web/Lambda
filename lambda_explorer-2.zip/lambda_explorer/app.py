"""
Lambda Explorer — browse every Lambda function in an AWS account, read
Python source directly, and decompile + read C#/.NET source on demand.

Run:
    pip install -r requirements.txt
    python app.py

See README.md for the .NET decompiler prerequisite and security notes
before pointing this at a real AWS account.
"""
import os
import io
import zipfile
import tempfile
import functools

from flask import (
    Flask, render_template, request, redirect, url_for, session,
    flash, jsonify, send_file, Response, abort
)
from flask_session import Session

from services.aws_client import build_session, verify_and_identify, CredentialError
from services.lambda_service import LambdaService, LambdaServiceError
from services.logs_service import LogsService, LogsServiceError
from services import code_viewer, decompiler, ai_scan

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("APP_SECRET_KEY", os.urandom(24))
app.config["SESSION_TYPE"] = "filesystem"
app.config["SESSION_FILE_DIR"] = os.path.join(os.path.dirname(__file__), ".flask_session")
app.config["SESSION_PERMANENT"] = False
Session(app)

# In-memory cache of extracted packages, keyed by f"{function_name}:{code_sha256}"
# so a redeploy invalidates it automatically. This intentionally lives in
# process memory, not in the user's browser session — extracted source can
# be large and doesn't belong in a cookie.
_PACKAGE_CACHE = {}

# Same idea for AI review results, keyed additionally by file path — avoids
# re-spending API tokens every time the same file's review is reopened.
_SCAN_CACHE = {}

# And for on-demand decompiles, keyed additionally by the .dll's path —
# clicking the same assembly twice doesn't re-run ilspycmd.
_DECOMPILE_CACHE = {}


# --------------------------------------------------------------------------
# Auth helpers
# --------------------------------------------------------------------------

def login_required(view):
    @functools.wraps(view)
    def wrapped(*args, **kwargs):
        if "aws_creds" not in session:
            flash("Connect an AWS account first.", "warning")
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped


def get_lambda_service() -> LambdaService:
    creds = session["aws_creds"]
    boto_session = build_session(
        creds["access_key"], creds["secret_key"], creds["region"], creds.get("session_token")
    )
    return LambdaService(boto_session)


def get_logs_service() -> LogsService:
    creds = session["aws_creds"]
    boto_session = build_session(
        creds["access_key"], creds["secret_key"], creds["region"], creds.get("session_token")
    )
    return LogsService(boto_session)


def get_anthropic_key() -> str:
    """Session-provided key wins if present; otherwise fall back to the
    environment the app itself was started with."""
    creds = session.get("aws_creds") or {}
    return creds.get("anthropic_api_key") or os.environ.get("ANTHROPIC_API_KEY", "")


# --------------------------------------------------------------------------
# Auth routes
# --------------------------------------------------------------------------

@app.route("/", methods=["GET"])
def index():
    return redirect(url_for("dashboard") if "aws_creds" in session else url_for("login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "GET":
        return render_template("login.html")

    access_key = request.form.get("access_key", "")
    secret_key = request.form.get("secret_key", "")
    session_token = request.form.get("session_token", "")
    region = request.form.get("region", "us-east-1")
    anthropic_api_key = request.form.get("anthropic_api_key", "").strip()

    try:
        boto_session = build_session(access_key, secret_key, region, session_token or None)
        identity = verify_and_identify(boto_session)
    except CredentialError as e:
        flash(str(e), "error")
        return render_template("login.html", region=region), 400

    session["aws_creds"] = {
        "access_key": access_key,
        "secret_key": secret_key,
        "session_token": session_token or None,
        "region": region,
        "anthropic_api_key": anthropic_api_key or None,
    }
    session["identity"] = identity
    flash(f"Connected to account {identity['account']}.", "success")
    return redirect(url_for("dashboard"))


@app.route("/logout")
def logout():
    session.clear()
    flash("Disconnected.", "success")
    return redirect(url_for("login"))


# --------------------------------------------------------------------------
# Dashboard
# --------------------------------------------------------------------------

@app.route("/dashboard")
@login_required
def dashboard():
    try:
        svc = get_lambda_service()
        functions = svc.list_functions()
    except LambdaServiceError as e:
        flash(f"Couldn't list functions: {e}", "error")
        functions = []

    for f in functions:
        f["_kind"] = code_viewer.classify_runtime(f.get("Runtime", ""))

    return render_template(
        "dashboard.html",
        functions=functions,
        identity=session.get("identity", {}),
        region=session["aws_creds"]["region"],
    )


# --------------------------------------------------------------------------
# Function source viewer
# --------------------------------------------------------------------------

def _load_package(name: str, force: bool = False) -> dict:
    """
    Ensures the deployment package for `name` is downloaded and extracted,
    then returns the cached bundle:
    {config, code_meta, kind, root, tree, decompiled}

    For .NET functions, nothing is decompiled here — `decompiled` starts
    empty and is filled in lazily, one assembly at a time, by the
    /function/<name>/decompile route as the user clicks .dll files.
    """
    svc = get_lambda_service()
    detail = svc.get_function(name)
    config = detail.get("Configuration", {})
    code_meta = detail.get("Code", {})
    runtime = config.get("Runtime", "")
    kind = code_viewer.classify_runtime(runtime)
    code_sha = config.get("CodeSha256", "nosha")
    cache_key = f"{name}:{code_sha}"

    if not force and cache_key in _PACKAGE_CACHE:
        return _PACKAGE_CACHE[cache_key]

    if "ImageUri" in code_meta and "Location" not in code_meta:
        bundle = {
            "config": config, "code_meta": code_meta, "kind": "image",
            "root": None, "tree": None, "decompiled": None,
        }
        _PACKAGE_CACHE[cache_key] = bundle
        return bundle

    zip_bytes = LambdaService.download_package(code_meta["Location"])
    root = code_viewer.extract_zip(zip_bytes)
    tree = code_viewer.build_tree(root)

    bundle = {
        "config": config, "code_meta": code_meta, "kind": kind,
        "root": root, "tree": tree,
        # rel dll path -> absolute temp dir holding its decompiled output;
        # populated on demand, see decompile_dll() below.
        "decompiled": {} if kind == "dotnet" else None,
    }
    _PACKAGE_CACHE[cache_key] = bundle
    return bundle


@app.route("/function/<name>")
@login_required
def view_function(name):
    try:
        bundle = _load_package(name)
    except LambdaServiceError as e:
        flash(f"Couldn't load {name}: {e}", "error")
        return redirect(url_for("dashboard"))
    except Exception as e:
        flash(f"Couldn't prepare {name} for viewing: {e}", "error")
        return redirect(url_for("dashboard"))

    default_path = None
    default_html = None
    if bundle["kind"] == "python":
        candidates = code_viewer.find_files(bundle["root"], [".py"])
        default_path = code_viewer.pick_default_file(candidates, handler=bundle["config"].get("Handler"))
        if default_path:
            text = code_viewer.read_text_file(bundle["root"], default_path)
            default_html = code_viewer.highlight_code(text, filename=default_path)
    # For .NET, nothing is decompiled yet at page load — the code panel
    # starts on the "pick a file" placeholder until a .dll is clicked.

    ilspy_missing = bundle["kind"] == "dotnet" and not decompiler.is_available()

    return render_template(
        "view_function.html",
        name=name,
        config=bundle["config"],
        kind=bundle["kind"],
        tree=bundle["tree"],
        ilspy_missing=ilspy_missing,
        default_path=default_path,
        default_html=default_html,
        is_image=(bundle["kind"] == "image"),
        code_meta=bundle["code_meta"],
        ai_available=ai_scan.is_available(),
    )


@app.route("/function/<name>/logs")
@login_required
def function_logs(name):
    """Latest CloudWatch Logs events for this function — works regardless
    of runtime, since every Lambda invocation logs there the same way."""
    try:
        svc = get_logs_service()
        events = svc.fetch_latest(name)
    except LogsServiceError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": f"Couldn't fetch logs: {e}"}), 400

    return jsonify({"events": events})


@app.route("/function/<name>/file")
@login_required
def get_file(name):
    path = request.args.get("path", "")
    try:
        bundle = _load_package(name)
    except Exception as e:
        return jsonify({"error": str(e)}), 400

    if bundle["kind"] == "image" or not bundle["root"]:
        return jsonify({"error": "This function has no browsable package."}), 400

    if not code_viewer.is_probably_text(bundle["root"], path):
        return jsonify({"binary": True, "path": path})

    try:
        text = code_viewer.read_text_file(bundle["root"], path)
    except FileNotFoundError:
        return jsonify({"error": "File not found."}), 404
    except ValueError:
        return jsonify({"error": "Invalid path."}), 400

    html = code_viewer.highlight_code(text, filename=path)
    return jsonify({"html": html, "path": path})


@app.route("/function/<name>/decompile")
@login_required
def decompile_dll(name):
    """
    Decompiles exactly one .dll, on click — nothing runs for the rest of
    the package. Grafts the output into the browsable tree at
    '<dll path>.decompiled/' via a symlink, so the normal /file and
    /file/download routes work on the decompiled .cs files unchanged.
    """
    path = request.args.get("path", "")
    try:
        bundle = _load_package(name)
    except Exception as e:
        return jsonify({"ok": False, "message": str(e)}), 400

    if bundle["kind"] != "dotnet" or not bundle["root"]:
        return jsonify({"ok": False, "message": "Not a .NET function."}), 400
    if not path.lower().endswith(".dll"):
        return jsonify({"ok": False, "message": "Not a .dll file."}), 400
    if not decompiler.is_available():
        return jsonify({
            "ok": False,
            "message": "ilspycmd isn't installed on this host. Run: dotnet tool install -g ilspycmd",
        }), 400

    code_sha = bundle["config"].get("CodeSha256", "nosha")
    cache_key = f"{name}:{code_sha}:{path}"
    if cache_key in _DECOMPILE_CACHE:
        return jsonify(_DECOMPILE_CACHE[cache_key])

    healthy, runtime_error = decompiler.check_runtime_health()
    if not healthy:
        result = {"ok": False, "dll": path, "runtime_error": True, "message": runtime_error}
        _DECOMPILE_CACHE[cache_key] = result
        return jsonify(result)

    try:
        abs_dll = code_viewer.resolve_safe_path(bundle["root"], path)
    except FileNotFoundError:
        return jsonify({"ok": False, "message": "File not found."}), 404
    except ValueError:
        return jsonify({"ok": False, "message": "Invalid path."}), 400

    out_dir = tempfile.mkdtemp(prefix="decompiled_one_")
    ok, message = decompiler.decompile_assembly(abs_dll, out_dir)
    result = {"ok": ok, "dll": path, "message": message, "runtime_error": False}

    if ok:
        link_name = path + ".decompiled"
        link_abs = os.path.join(bundle["root"], link_name)
        if not os.path.exists(link_abs):
            os.symlink(out_dir, link_abs)
        result["tree"] = code_viewer.build_tree(out_dir, path_prefix=link_name)
        bundle["decompiled"][path] = out_dir
        # Keep the cached bundle's full tree in sync too, so a page reload
        # after decompiling still shows the grafted folder.
        bundle["tree"] = code_viewer.build_tree(bundle["root"])

    _DECOMPILE_CACHE[cache_key] = result
    return jsonify(result)


@app.route("/function/<name>/file/download")
@login_required
def download_file(name):
    """Downloads exactly the single file currently open in the viewer —
    works for anything in the tree, source or decompiled, text or binary."""
    path = request.args.get("path", "")
    try:
        bundle = _load_package(name)
    except Exception as e:
        flash(f"Couldn't load {name}: {e}", "error")
        return redirect(url_for("view_function", name=name))

    if bundle["kind"] == "image" or not bundle["root"]:
        flash("This function has no browsable package to download from.", "error")
        return redirect(url_for("view_function", name=name))

    try:
        data = code_viewer.read_file_bytes(bundle["root"], path)
    except FileNotFoundError:
        abort(404)
    except ValueError:
        abort(400)

    return send_file(
        io.BytesIO(data), as_attachment=True,
        download_name=os.path.basename(path) or "file",
    )


@app.route("/function/<name>/file/scan")
@login_required
def scan_file(name):
    """AI-assisted review of whichever file is open: a plain-English
    summary plus a best-effort vulnerability pass, via the Anthropic API."""
    path = request.args.get("path", "")
    api_key = get_anthropic_key()
    if not api_key:
        return jsonify({
            "error": "no_api_key",
            "message": "No Anthropic API key configured. Add one on the connect page, "
                       "or set ANTHROPIC_API_KEY in the environment this app runs in.",
        }), 400

    try:
        bundle = _load_package(name)
    except Exception as e:
        return jsonify({"error": "load_failed", "message": str(e)}), 400

    if bundle["kind"] == "image" or not bundle["root"]:
        return jsonify({"error": "unsupported", "message": "No browsable package."}), 400

    if not code_viewer.is_probably_text(bundle["root"], path):
        return jsonify({"error": "binary", "message": "Can't scan a binary file."}), 400

    code_sha = bundle["config"].get("CodeSha256", "nosha")
    cache_key = f"{name}:{code_sha}:{path}"
    if cache_key in _SCAN_CACHE:
        return jsonify(_SCAN_CACHE[cache_key])

    try:
        text = code_viewer.read_text_file(bundle["root"], path)
    except FileNotFoundError:
        return jsonify({"error": "not_found", "message": "File not found."}), 404
    except ValueError:
        return jsonify({"error": "invalid_path", "message": "Invalid path."}), 400

    try:
        result = ai_scan.scan_code(api_key, text, path, name)
    except ai_scan.ScanError as e:
        return jsonify({"error": "scan_failed", "message": str(e)}), 502

    _SCAN_CACHE[cache_key] = result
    return jsonify(result)


@app.route("/function/<name>/download")
@login_required
def download_package(name):
    try:
        svc = get_lambda_service()
        detail = svc.get_function(name)
        code_meta = detail.get("Code", {})
        if "Location" not in code_meta:
            flash("This function is image-based; there's no zip package to download.", "error")
            return redirect(url_for("view_function", name=name))
        zip_bytes = LambdaService.download_package(code_meta["Location"])
    except LambdaServiceError as e:
        flash(f"Couldn't download {name}: {e}", "error")
        return redirect(url_for("view_function", name=name))

    return send_file(
        io.BytesIO(zip_bytes), mimetype="application/zip",
        as_attachment=True, download_name=f"{name}.zip",
    )


@app.route("/function/<name>/download-decompiled")
@login_required
def download_decompiled(name):
    try:
        bundle = _load_package(name)
    except Exception as e:
        flash(f"Couldn't prepare {name}: {e}", "error")
        return redirect(url_for("view_function", name=name))

    if bundle["kind"] != "dotnet" or not bundle["root"]:
        flash("Decompiled download is only available for .NET functions.", "error")
        return redirect(url_for("view_function", name=name))

    decompiled = bundle.get("decompiled") or {}
    if not decompiled:
        flash("Nothing has been decompiled yet — click a .dll in the tree first.", "error")
        return redirect(url_for("view_function", name=name))

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for dll_path, out_dir in decompiled.items():
            base = os.path.dirname(dll_path)
            folder_name = os.path.basename(dll_path) + ".decompiled"
            for dirpath, _, filenames in os.walk(out_dir):
                for f in filenames:
                    full = os.path.join(dirpath, f)
                    arc = os.path.join(base, folder_name, os.path.relpath(full, out_dir))
                    zf.write(full, arc)
    buf.seek(0)
    return send_file(
        buf, mimetype="application/zip",
        as_attachment=True, download_name=f"{name}-decompiled.zip",
    )


# --------------------------------------------------------------------------
# Assets
# --------------------------------------------------------------------------

@app.route("/assets/pygments.css")
def pygments_css():
    return Response(code_viewer.pygments_css(), mimetype="text/css")


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5050, debug=True)
