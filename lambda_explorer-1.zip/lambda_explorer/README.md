# Lambda Explorer

A Flask app that connects to an AWS account with an access key / secret key,
lists every Lambda function, and lets you read the source straight from the
browser:

- **Python functions** — the deployment package is downloaded and unzipped,
  and every file is browsable in a VS Code-style tree + syntax-highlighted
  panel.
- **C# / .NET functions** — the package is downloaded and browsable
  immediately, with `.dll` files shown right in the tree. Nothing gets
  decompiled until you click a specific one — that runs
  [ILSpy](https://github.com/icsharpcode/ILSpy) against just that assembly
  and expands it into `.cs` source in place, leaving every other DLL in the
  package untouched.
- **Container-image functions** — flagged as such, with the image URI shown
  (there's no zip package to open in that case).

Every function page also has one-click **download the raw package** and
(for .NET) **download the decompiled source as a zip** — that one bundles
up whatever you've decompiled so far in the session, not the whole
package. Inside the code viewer, whichever file is open gets its own
**Download file** button and a **✦ Scan with AI** button that sends just
that file to Claude for a plain-English explanation of what it does plus
a best-effort vulnerability review.

## Setup

```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### C# decompilation prerequisite

Decompiling `.dll` files requires **ilspycmd**, the command-line tool for
ILSpy. It's a .NET global tool, not a Python package:

```bash
# requires the .NET SDK: https://dotnet.microsoft.com/download
dotnet tool install -g ilspycmd
```

Make sure `ilspycmd` is on the `PATH` of whatever shell runs `python app.py`.
If it isn't installed, the app still works — C# functions just show a
banner explaining that, and clicking a `.dll` reports the same thing
inline instead of trying, so you can download the raw package instead.

### AI review prerequisite (optional)

"✦ Scan with AI" calls the Anthropic API directly, so it needs a key:

```bash
export ANTHROPIC_API_KEY=sk-ant-...
```

or paste one into the optional field on the connect page instead — either
works, and the field is only there for when you'd rather not set an
environment variable. If no key is configured anywhere, the button still
appears; clicking it just explains how to add one instead of erroring out.
Nothing is sent to Anthropic until you click the button on a specific file,
and only that one file's contents are sent.

## Running it

```bash
python app.py
```

Then open `http://127.0.0.1:5050`, paste in an access key / secret key
(and a session token if you're using temporary STS credentials) and a
region, and connect.

The IAM identity needs, at minimum:

```json
{
  "Effect": "Allow",
  "Action": ["lambda:ListFunctions", "lambda:GetFunction"],
  "Resource": "*"
}
```

## Security notes — read before pointing this at a real account

This tool is built the way it was asked for: raw access-key/secret-key
login. A few things worth knowing about that trade-off:

- **Credentials are kept server-side**, in a `Flask-Session` filesystem
  store under `.flask_session/` next to the app — not in a browser cookie
  (a default Flask session cookie is only *signed*, not encrypted, so a
  secret key would be readable by anyone who got the cookie). Even so,
  treat `.flask_session/` as sensitive: it's plaintext on disk for as long
  as the session lives.
- **Long-lived access keys are the highest-risk form of AWS credential.**
  If you can, generate temporary credentials instead (`aws sts
  assume-role` / `get-session-token`) and paste those in along with the
  session token field — same login form, much shorter blast radius if
  they leak.
- **This app is meant to run locally or on a trusted internal host**, not
  be exposed on the open internet — anyone who can reach it can reach
  everything those AWS credentials can reach, plus the full decompiled
  source of your C# functions. There's no app-level login in front of the
  AWS login step; put it behind a VPN or add one if that's not true for
  your setup.
- Downloaded packages are cached **in server memory** for the life of the
  process (keyed to each function's code hash, so a redeploy is picked up
  automatically) and extracted to the OS temp directory. Decompiled output
  is cached the same way, per assembly, so re-clicking a `.dll` you've
  already decompiled doesn't re-run `ilspycmd`. Restarting the app clears
  everything; temp directories are not auto-deleted, so periodically clear
  your temp folder if you're doing this a lot.
- **AI review sends the open file's source to Anthropic's API.** That's the
  whole point of the feature, but it's worth being deliberate about it —
  don't scan files with hardcoded secrets or anything else you wouldn't
  want leaving the machine, and treat the reviews as a fast first pass, not
  a finding you'd cite in an audit. Results are cached in the same server
  memory as everything else, keyed by function + file + code hash, so
  reopening a review doesn't re-spend API tokens.

## How the C# decompilation works

Nothing decompiles until you click a `.dll` in the tree. That click runs
`ilspycmd` against just that one assembly — project mode first (`-p`, one
`.cs` file per type — the closest thing to real source layout), falling
back to a single combined `.cs` file if project mode fails for that
particular assembly. The result expands in place under that `.dll`'s row
in the tree, and a small "Decompile activity" log at the top of the page
records every attempt, success or failure, as you go.

A broken `.dll` doesn't affect any others — each one is independent, and
a failure just marks that row and moves on. The one exception is if the
.NET runtime itself can't start at all (see the troubleshooting section
below): the app detects that on the first click and shows one clear
banner instead of letting you discover it failure by failure.

Decompiled output is best-effort — it's the same technique tools like
dnSpy and ILSpy's GUI use, and works well for typical managed Lambda
handlers, but variable names, comments, and some language constructs from
the original source are not recoverable from IL and won't come back
exactly as written.

### Troubleshooting: "GC heap initialization failed" / CoreCLR won't start

If clicking a `.dll` reports an error about the GC reserving a huge
amount of memory (something like `0x8007000E` and a mention of ~256 GiB),
that's not about that assembly at all — it means the .NET runtime can't
start as a process on this machine, full stop, and every other `.dll`
will fail the same way. To fix the underlying issue:

- Run `ilspycmd --version` (or just `dotnet --version`) directly in the
  same shell — if that alone throws the same error with no app involved,
  it confirms this is a machine-level problem, not this app.
- Check for a 32-bit `dotnet` shadowing the 64-bit one (`dotnet --info`
  shows the architecture); a 32-bit process can't reserve that much address
  space and fails immediately. Reinstall the tool once the right one is
  first on `PATH`: `dotnet tool uninstall -g ilspycmd && dotnet tool install -g ilspycmd`.
- Locked-down corporate machines, Windows Sandbox, and memory-limited
  VMs/containers sometimes cap a process's virtual address space via a job
  object — that produces exactly this error too. On Linux this often shows
  up as a `ulimit -v` restriction or a container/cgroup memory limit; on a
  sandboxed runtime (gVisor and similar) that emulates `/proc`, neither may
  be adjustable from inside the container at all.
- As a workaround either way, capping the GC heap avoids the huge upfront
  reservation:
  ```
  export DOTNET_GCHeapHardLimit=0x10000000   # Linux/macOS
  setx DOTNET_GCHeapHardLimit 10000000       # Windows — open a new terminal after
  ```
  then start `python app.py` from that same shell so the decompiler
  subprocess inherits it. If the environment truly can't run CoreCLR at
  all (some sandboxes can't), download the raw package instead and run
  `ilspycmd` against it on a normal machine.
