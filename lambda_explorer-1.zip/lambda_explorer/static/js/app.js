// Lambda Explorer — client-side behavior.
// Three independent, small pieces: the dashboard name filter, the
// file-tree / code-panel wiring on the function viewer page (including
// click-to-decompile .dll rows), and the download / AI-review buttons that
// act on whichever file is open.

(function dashboardFilter() {
  const input = document.getElementById("fn-filter");
  const table = document.getElementById("fn-table");
  if (!input || !table) return;

  input.addEventListener("input", () => {
    const q = input.value.trim().toLowerCase();
    table.querySelectorAll(".fn-row").forEach((row) => {
      const name = row.querySelector(".fn-name").textContent.toLowerCase();
      row.style.display = name.includes(q) ? "" : "none";
    });
  });
})();

(function fileTree() {
  const state = window.__LAMBDA_EXPLORER__;
  const treeEl = document.getElementById("file-tree");
  if (!state || !treeEl) return;

  const codePanel = document.getElementById("code-panel");
  const statusFile = document.getElementById("status-file");
  const toolbarPath = document.getElementById("code-toolbar-path");
  const downloadBtn = document.getElementById("btn-download-file");
  const scanBtn = document.getElementById("btn-scan-ai");

  const aiPanel = document.getElementById("ai-panel");
  const aiPanelFile = document.getElementById("ai-panel-file");
  const aiPanelBody = document.getElementById("ai-panel-body");
  const aiPanelClose = document.getElementById("ai-panel-close");

  const runtimeBanner = document.getElementById("runtime-error-banner");
  const decompileLog = document.getElementById("decompile-log");
  const decompileLogList = document.getElementById("decompile-log-list");

  let activeLink = null;
  let currentPath = state.initialPath || null;
  let runtimeBroken = false; // once true, stop hitting the decompile endpoint entirely

  function escapeHtml(s) {
    const div = document.createElement("div");
    div.textContent = s == null ? "" : s;
    return div.innerHTML;
  }

  // ---- file tree rendering ----------------------------------------

  function iconFor(name, isDir) {
    if (isDir) return "▸";
    if (name.toLowerCase().endsWith(".dll")) return "📦";
    if (name.endsWith(".py")) return "🐍";
    if (name.endsWith(".cs")) return "🔷";
    if (name.endsWith(".json")) return "{}";
    return "▪";
  }

  function isDll(name) {
    return name.toLowerCase().endsWith(".dll");
  }

  function renderNode(node, container, depth) {
    if (node.type === "dir") {
      if (depth > 0) {
        const dirRow = document.createElement("div");
        dirRow.className = "tree-row tree-row--dir";
        dirRow.style.paddingLeft = (depth * 14) + "px";
        dirRow.textContent = iconFor(node.name, true) + " " + node.name;
        const childWrap = document.createElement("div");
        childWrap.className = "tree-children";
        dirRow.addEventListener("click", () => {
          childWrap.classList.toggle("collapsed");
          dirRow.classList.toggle("collapsed");
        });
        container.appendChild(dirRow);
        container.appendChild(childWrap);
        (node.children || []).forEach((child) => renderNode(child, childWrap, depth + 1));
      } else {
        (node.children || []).forEach((child) => renderNode(child, container, depth));
      }
      return;
    }

    if (state.kind === "dotnet" && isDll(node.name)) {
      renderDllRow(node, container, depth);
      return;
    }

    const fileRow = document.createElement("a");
    fileRow.className = "tree-row tree-row--file";
    fileRow.style.paddingLeft = (depth * 14) + "px";
    fileRow.textContent = iconFor(node.name, false) + " " + node.name;
    fileRow.href = "javascript:void(0)";
    fileRow.dataset.path = node.path;
    fileRow.addEventListener("click", () => openFile(node.path, fileRow));
    container.appendChild(fileRow);
  }

  // ---- .dll rows: click to decompile, on demand, one at a time ------

  function renderDllRow(node, container, depth) {
    const row = document.createElement("div");
    row.className = "tree-row tree-row--dll";
    row.style.paddingLeft = (depth * 14) + "px";
    row.dataset.path = node.path;
    setDllRowLabel(row, node.name, "idle");

    const childWrap = document.createElement("div");
    childWrap.className = "tree-children collapsed";
    container.appendChild(row);
    container.appendChild(childWrap);

    let decompiled = false; // has a successful response already populated childWrap

    row.addEventListener("click", () => {
      if (decompiled) {
        childWrap.classList.toggle("collapsed");
        row.classList.toggle("collapsed");
        return;
      }
      if (row.dataset.state === "loading") return;
      if (runtimeBroken) {
        flashRowMessage(row, "Runtime is broken — see the banner above.");
        return;
      }
      if (state.ilspyMissing) {
        flashRowMessage(row, "ilspycmd isn't installed — see the banner above.");
        return;
      }
      runDecompile(node, row, childWrap, depth, (ok) => {
        decompiled = ok;
      });
    });
  }

  function setDllRowLabel(row, name, mode) {
    row.dataset.state = mode;
    let suffix = "";
    let icon = "📦";
    if (mode === "loading") { icon = "⏳"; suffix = " — decompiling…"; }
    else if (mode === "ok") { icon = "📦"; suffix = " — decompiled"; }
    else if (mode === "fail") { icon = "📦"; suffix = " — failed"; }
    row.textContent = icon + " " + name + suffix;
    row.classList.toggle("tree-row--dll-fail", mode === "fail");
  }

  function flashRowMessage(row, message) {
    const original = row.textContent;
    row.title = message;
    row.textContent = "⚠ " + message;
    setTimeout(() => { row.textContent = original; }, 2200);
  }

  function runDecompile(node, row, childWrap, depth, done) {
    setDllRowLabel(row, node.name, "loading");

    fetch(state.decompileUrl + "?path=" + encodeURIComponent(node.path))
      .then((r) => r.json())
      .then((data) => {
        if (data.runtime_error) {
          runtimeBroken = true;
          setDllRowLabel(row, node.name, "fail");
          row.title = data.message || "The .NET runtime failed to start.";
          showRuntimeBanner(data.message);
          logActivity(node.path, false, "the .NET runtime failed to start — see the banner above");
          done(false);
          return;
        }
        if (!data.ok) {
          setDllRowLabel(row, node.name, "fail");
          row.title = data.message || "Decompile failed.";
          logActivity(node.path, false, data.message || "decompile failed");
          done(false);
          return;
        }

        setDllRowLabel(row, node.name, "ok");
        childWrap.classList.remove("collapsed");
        row.classList.remove("collapsed");
        (data.tree.children || []).forEach((child) => renderNode(child, childWrap, depth + 1));
        logActivity(node.path, true, data.message);

        const firstFile = firstFileIn(data.tree);
        if (firstFile) {
          const link = childWrap.querySelector('[data-path="' + CSS.escape(firstFile) + '"]');
          openFile(firstFile, link || null);
        }
        done(true);
      })
      .catch(() => {
        setDllRowLabel(row, node.name, "fail");
        row.title = "Couldn't reach the decompile endpoint.";
        logActivity(node.path, false, "couldn't reach the decompile endpoint");
        done(false);
      });
  }

  function firstFileIn(node) {
    if (node.type === "file") return node.path;
    for (const child of node.children || []) {
      const found = firstFileIn(child);
      if (found) return found;
    }
    return null;
  }

  function showRuntimeBanner(message) {
    if (!runtimeBanner) return;
    runtimeBanner.innerHTML =
      '<strong>The .NET runtime failed to start</strong>, so nothing can be decompiled on this host — ' +
      "this isn't about any particular assembly, it's <code>ilspycmd</code> itself failing to launch. " +
      "The raw package is still browsable and downloadable above." +
      '<details class="banner-details"><summary>Show the underlying error</summary>' +
      '<pre class="banner-pre">' + escapeHtml(message) + "</pre></details>" +
      "Common causes: a 32-bit <code>dotnet</code> being picked up instead of 64-bit, or a virtual-memory " +
      "quota enforced on the process (sandboxing, a locked-down machine, a memory-limited VM/container). " +
      "Run <code>dotnet --version</code> in the same shell to confirm whether it's system-wide.";
    runtimeBanner.classList.remove("hidden");
  }

  function logActivity(path, ok, message) {
    if (!decompileLog || !decompileLogList) return;
    decompileLog.classList.remove("hidden");
    decompileLog.open = true;
    const li = document.createElement("li");
    li.className = ok ? "ok" : "fail";
    const pathSpan = document.createElement("span");
    pathSpan.className = "mono";
    pathSpan.textContent = path;
    li.appendChild(pathSpan);
    li.appendChild(document.createTextNode(" — " + message));
    decompileLogList.appendChild(li);
  }

  // ---- toolbar (download / scan) -----------------------------------

  function updateToolbar(path, isBinary) {
    currentPath = path;
    if (toolbarPath) toolbarPath.textContent = path;

    if (downloadBtn) {
      downloadBtn.href = state.downloadFileUrl + "?path=" + encodeURIComponent(path);
      downloadBtn.classList.remove("btn--disabled");
    }
    if (scanBtn) {
      scanBtn.disabled = !!isBinary;
      scanBtn.classList.toggle("btn--disabled", !!isBinary);
      scanBtn.title = isBinary ? "Can't scan a binary file." : "";
    }
  }

  // ---- code panel -----------------------------------------------

  function openFile(path, linkEl) {
    if (activeLink) activeLink.classList.remove("active");
    if (linkEl) {
      linkEl.classList.add("active");
      activeLink = linkEl;
    }
    codePanel.innerHTML = '<div class="empty-editor"><div class="empty-cursor">_</div><p>Loading…</p></div>';
    fetch(state.fileUrl + "?path=" + encodeURIComponent(path))
      .then((r) => r.json())
      .then((data) => {
        if (data.error) {
          codePanel.innerHTML = '<div class="empty-editor"><p>' + escapeHtml(data.error) + '</p></div>';
          updateToolbar(path, true);
          return;
        }
        if (data.binary) {
          codePanel.innerHTML = '<div class="empty-editor"><p>Binary file — not shown here. Download it instead.</p></div>';
          updateToolbar(path, true);
        } else {
          codePanel.innerHTML = data.html;
          updateToolbar(path, false);
        }
        if (statusFile) statusFile.textContent = path;
      })
      .catch(() => {
        codePanel.innerHTML = '<div class="empty-editor"><p>Couldn\'t load that file.</p></div>';
      });
  }

  // ---- AI review panel --------------------------------------------

  function severityRank(sev) {
    const order = { critical: 0, high: 1, medium: 2, low: 3 };
    const r = order[(sev || "").toLowerCase()];
    return r === undefined ? 4 : r;
  }

  function renderScanResult(data) {
    if (data.error) {
      const helpful = data.error === "no_api_key";
      aiPanelBody.innerHTML =
        '<div class="ai-message ' + (helpful ? "ai-message--info" : "ai-message--error") + '">' +
        escapeHtml(data.message || "Something went wrong running the review.") +
        "</div>";
      return;
    }

    const vulns = (data.vulnerabilities || []).slice().sort((a, b) => severityRank(a.severity) - severityRank(b.severity));

    let html = '<div class="ai-disclaimer">AI-generated review — a fast first pass, not a substitute for a real audit.</div>';
    html += '<div class="ai-summary"><h4>What this file does</h4><p>' + escapeHtml(data.summary || "—") + "</p></div>";

    html += '<div class="ai-vulns"><h4>Security review';
    html += vulns.length ? " — " + vulns.length + " finding" + (vulns.length === 1 ? "" : "s") : "";
    html += "</h4>";

    if (!vulns.length) {
      html += '<div class="ai-message ai-message--ok">No obvious vulnerabilities found in this file.</div>';
    } else {
      vulns.forEach((v) => {
        const sev = (v.severity || "low").toLowerCase();
        html +=
          '<div class="vuln-card vuln-card--' + escapeHtml(sev) + '">' +
          '<div class="vuln-head"><span class="pill pill--sev-' + escapeHtml(sev) + '">' + escapeHtml(sev) + "</span>" +
          '<span class="vuln-title">' + escapeHtml(v.title || "Untitled finding") + "</span></div>" +
          '<p class="vuln-desc">' + escapeHtml(v.description || "") + "</p>" +
          (v.recommendation ? '<p class="vuln-fix"><strong>Fix:</strong> ' + escapeHtml(v.recommendation) + "</p>" : "") +
          "</div>";
      });
    }
    html += "</div>";

    if (data.notes) {
      html += '<div class="ai-notes"><h4>Other notes</h4><p>' + escapeHtml(data.notes) + "</p></div>";
    }

    aiPanelBody.innerHTML = html;
  }

  function runScan() {
    if (!currentPath || !scanBtn || scanBtn.disabled) return;
    aiPanel.classList.remove("hidden");
    if (aiPanelFile) aiPanelFile.textContent = currentPath;
    aiPanelBody.innerHTML = '<div class="empty-editor"><div class="empty-cursor">_</div><p>Reviewing with AI…</p></div>';

    fetch(state.scanFileUrl + "?path=" + encodeURIComponent(currentPath))
      .then((r) => r.json())
      .then(renderScanResult)
      .catch(() => {
        aiPanelBody.innerHTML = '<div class="ai-message ai-message--error">Couldn\'t reach the review endpoint.</div>';
      });
  }

  if (scanBtn) scanBtn.addEventListener("click", runScan);
  if (aiPanelClose) aiPanelClose.addEventListener("click", () => aiPanel.classList.add("hidden"));

  // ---- init ---------------------------------------------------------

  renderNode(state.tree, treeEl, 0);

  if (state.initialPath) {
    const link = treeEl.querySelector('[data-path="' + CSS.escape(state.initialPath) + '"]');
    if (link) {
      link.classList.add("active");
      activeLink = link;
    }
    updateToolbar(state.initialPath, false);
  }
})();
