// Lambda Explorer — client-side behavior.
// Two independent, small pieces: the dashboard name filter, and the
// file-tree / code-panel wiring on the function viewer page.

(function dashboardFilter() {
  const input = document.getElementById("fn-filter");
  const table = document.getElementById("fn-table");
  if (!input || !table) return;

  input.addEventListener("input", () => {
    const q = input.value.trim().toLowerCase();
    table.querySelectorAll(".fn-row").forEach((row) => {
      const name = row.querySelector(".fn-name").textContent.toLowerCase();
      row.style.display = name.includes(q) ? "" : "none";
    });
  });
})();

(function fileTree() {
  const state = window.__LAMBDA_EXPLORER__;
  const treeEl = document.getElementById("file-tree");
  if (!state || !treeEl) return;

  const codePanel = document.getElementById("code-panel");
  const statusFile = document.getElementById("status-file");
  let activeLink = null;

  function iconFor(name, isDir) {
    if (isDir) return "▸";
    if (name.endsWith(".py")) return "🐍";
    if (name.endsWith(".cs")) return "🔷";
    if (name.endsWith(".json")) return "{}";
    return "▪";
  }

  function renderNode(node, container, depth) {
    if (node.type === "dir") {
      // Skip rendering the synthetic root node's own row.
      if (depth > 0) {
        const dirRow = document.createElement("div");
        dirRow.className = "tree-row tree-row--dir";
        dirRow.style.paddingLeft = (depth * 14) + "px";
        dirRow.textContent = iconFor(node.name, true) + " " + node.name;
        const childWrap = document.createElement("div");
        childWrap.className = "tree-children";
        dirRow.addEventListener("click", () => {
          childWrap.classList.toggle("collapsed");
          dirRow.classList.toggle("collapsed");
        });
        container.appendChild(dirRow);
        container.appendChild(childWrap);
        (node.children || []).forEach((child) => renderNode(child, childWrap, depth + 1));
      } else {
        (node.children || []).forEach((child) => renderNode(child, container, depth));
      }
    } else {
      const fileRow = document.createElement("a");
      fileRow.className = "tree-row tree-row--file";
      fileRow.style.paddingLeft = (depth * 14) + "px";
      fileRow.textContent = iconFor(node.name, false) + " " + node.name;
      fileRow.href = "javascript:void(0)";
      fileRow.dataset.path = node.path;
      fileRow.addEventListener("click", () => openFile(node.path, fileRow));
      container.appendChild(fileRow);
    }
  }

  function openFile(path, linkEl) {
    if (activeLink) activeLink.classList.remove("active");
    if (linkEl) {
      linkEl.classList.add("active");
      activeLink = linkEl;
    }
    codePanel.innerHTML = '<div class="empty-editor"><div class="empty-cursor">_</div><p>Loading…</p></div>';
    fetch(state.fileUrl + "?path=" + encodeURIComponent(path))
      .then((r) => r.json())
      .then((data) => {
        if (data.error) {
          codePanel.innerHTML = '<div class="empty-editor"><p>' + escapeHtml(data.error) + '</p></div>';
          return;
        }
        if (data.binary) {
          codePanel.innerHTML = '<div class="empty-editor"><p>Binary file — not shown here. Download the package to inspect it.</p></div>';
        } else {
          codePanel.innerHTML = data.html;
        }
        if (statusFile) statusFile.textContent = path;
      })
      .catch(() => {
        codePanel.innerHTML = '<div class="empty-editor"><p>Couldn\'t load that file.</p></div>';
      });
  }

  function escapeHtml(s) {
    const div = document.createElement("div");
    div.textContent = s;
    return div.innerHTML;
  }

  renderNode(state.tree, treeEl, 0);

  if (state.initialPath) {
    const link = treeEl.querySelector('[data-path="' + CSS.escape(state.initialPath) + '"]');
    if (link) {
      link.classList.add("active");
      activeLink = link;
    }
  }
})();
