// Lambda Explorer — client-side behavior.
//
// Everything lives inside one persistent shell page: a tab bar plus a
// "Functions" (dashboard) tab that's always present, and one additional
// tab per function someone has opened. Opening a function fetches an
// HTML fragment (/function/<name>/panel) and injects it into a new tab
// instead of navigating — the whole point is that switching between
// already-open tabs costs nothing (no request at all), and opening a new
// one costs one small fragment fetch instead of a full page's worth of
// CSS/JS/fonts, which is what actually matters for "fast on mobile."
//
// Because more than one function's worth of markup can be in the DOM at
// once, every per-tab lookup below is scoped to that tab's own container
// (`root.querySelector(...)`) rather than `document.getElementById(...)`
// — two tabs can reuse the same ids without colliding, since a scoped
// query only ever searches its own tab's subtree.

function escapeHtml(s) {
  const div = document.createElement("div");
  div.textContent = s == null ? "" : s;
  return div.innerHTML;
}

function cssEscape(s) {
  if (window.CSS && CSS.escape) return CSS.escape(s);
  return String(s).replace(/[^a-zA-Z0-9_-]/g, "\\$&");
}

window.LambdaExplorer = window.LambdaExplorer || {};

// ============================================================
// Tab manager — owns the tab bar and tab-panel containers. The DOM is
// the source of truth for "which tabs are open" (no separate JS state to
// keep in sync): a tab is open if a `.tab-item[data-tab-id]` exists.
// ============================================================
(function tabManager() {
  function tabBarEl() { return document.getElementById("tab-bar"); }
  function tabPanelsEl() { return document.getElementById("tab-panels"); }

  function findTabButton(tabId) {
    const bar = tabBarEl();
    return bar ? bar.querySelector('.tab-item[data-tab-id="' + cssEscape(tabId) + '"]') : null;
  }
  function findTabPanel(tabId) {
    const panels = tabPanelsEl();
    return panels ? panels.querySelector('.tab-panel[data-tab-id="' + cssEscape(tabId) + '"]') : null;
  }

  // Scripts inserted via innerHTML never execute (browser spec) — every
  // fragment we fetch needs its trailing <script> re-created like this to
  // actually run. async=false on external scripts preserves relative
  // load order (matters for the CodeMirror core script vs its Python
  // mode script) while still loading them without blocking.
  function executeScripts(container) {
    Array.from(container.querySelectorAll("script")).forEach((oldScript) => {
      const newScript = document.createElement("script");
      Array.from(oldScript.attributes).forEach((attr) => newScript.setAttribute(attr.name, attr.value));
      if (oldScript.src) newScript.async = false;
      newScript.textContent = oldScript.textContent;
      oldScript.parentNode.replaceChild(newScript, oldScript);
    });
  }

  function setTitle(tabId) {
    document.title = (tabId === "dashboard" ? "Functions" : tabId) + " · Lambda Explorer";
  }

  function switchTo(tabId, opts) {
    opts = opts || {};
    const bar = tabBarEl(), panels = tabPanelsEl();
    if (!bar || !panels) return;
    bar.querySelectorAll(".tab-item").forEach((el) => el.classList.toggle("active", el.dataset.tabId === tabId));
    panels.querySelectorAll(".tab-panel").forEach((el) => el.classList.toggle("active", el.dataset.tabId === tabId));

    const btn = findTabButton(tabId);
    if (btn && btn.scrollIntoView) btn.scrollIntoView({ block: "nearest", inline: "nearest" });

    if (!opts.skipHistory) {
      const url = tabId === "dashboard" ? "/dashboard" : "/function/" + encodeURIComponent(tabId);
      if (window.location.pathname !== url) history.pushState({ tabId: tabId }, "", url);
    }
    setTitle(tabId);
  }

  function closeTab(tabId) {
    const panel = findTabPanel(tabId);
    if (panel && panel.dataset.editing === "true") {
      if (!confirm('"' + tabId + '" has unsaved edits open. Close the tab and discard them?')) return;
    }
    const btn = findTabButton(tabId);
    const wasActive = btn && btn.classList.contains("active");
    if (btn) btn.remove();
    if (panel) panel.remove();
    if (wasActive) switchTo("dashboard");
  }

  function ensureDashboardLoaded(callback) {
    const panel = findTabPanel("dashboard");
    if (!panel) { if (callback) callback(); return; }
    if (panel.dataset.loaded === "true") { if (callback) callback(); return; }
    panel.innerHTML = '<div class="tab-loading"><div class="empty-cursor">_</div><p>Loading…</p></div>';
    fetch("/dashboard/panel")
      .then((r) => r.text())
      .then((html) => {
        panel.innerHTML = html;
        panel.dataset.loaded = "true";
        executeScripts(panel);
        if (callback) callback();
      })
      .catch(() => {
        panel.innerHTML = '<div class="tab-loading"><p>Couldn\'t load the function list.</p></div>';
      });
  }

  function openFunctionTab(name, opts) {
    opts = opts || {};
    if (findTabButton(name)) {
      switchTo(name);
      if (opts.openLogs) {
        const panel = findTabPanel(name);
        const logsBtn = panel && panel.querySelector("#btn-view-logs");
        if (logsBtn) logsBtn.click();
      }
      return;
    }

    const bar = tabBarEl(), panels = tabPanelsEl();
    if (!bar || !panels) {
      window.location.href = "/function/" + encodeURIComponent(name) + (opts.openLogs ? "?logs=1" : "");
      return;
    }

    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "tab-item";
    btn.setAttribute("role", "tab");
    btn.dataset.tabId = name;
    const label = document.createElement("span");
    label.className = "tab-label";
    label.textContent = name;
    const close = document.createElement("span");
    close.className = "tab-close";
    close.title = "Close tab";
    close.textContent = "×";
    close.dataset.closeTab = name;
    btn.appendChild(label);
    btn.appendChild(close);
    bar.appendChild(btn);

    const panel = document.createElement("div");
    panel.className = "tab-panel";
    panel.dataset.tabId = name;
    panel.innerHTML = '<div class="tab-loading"><div class="empty-cursor">_</div><p>Loading ' + escapeHtml(name) + '…</p></div>';
    panels.appendChild(panel);

    switchTo(name);

    const url = "/function/" + encodeURIComponent(name) + "/panel" + (opts.openLogs ? "?logs=1" : "");
    fetch(url)
      .then((r) => r.text())
      .then((html) => {
        panel.innerHTML = html;
        executeScripts(panel);
      })
      .catch(() => {
        panel.innerHTML = '<div class="tab-loading"><p>Couldn\'t load this function.</p></div>';
      });
  }

  // One set of delegated listeners handles every tab everywhere, including
  // tabs that don't exist yet at page-load time.
  document.addEventListener("click", (e) => {
    const openEl = e.target.closest("[data-open-tab]");
    if (openEl) {
      e.preventDefault();
      openFunctionTab(openEl.dataset.openTab, { openLogs: openEl.dataset.openTabLogs === "1" });
      return;
    }
    const closeEl = e.target.closest("[data-close-tab]");
    if (closeEl) {
      e.preventDefault();
      e.stopPropagation();
      closeTab(closeEl.dataset.closeTab);
      return;
    }
    const switchEl = e.target.closest("[data-switch-tab]");
    if (switchEl) {
      e.preventDefault();
      const tabId = switchEl.dataset.switchTab;
      if (tabId === "dashboard") ensureDashboardLoaded(() => switchTo(tabId));
      else switchTo(tabId);
      return;
    }
    const tabItem = e.target.closest(".tab-item");
    if (tabItem && tabBarEl() && tabBarEl().contains(tabItem)) {
      const tabId = tabItem.dataset.tabId;
      if (tabId === "dashboard") ensureDashboardLoaded(() => switchTo(tabId));
      else switchTo(tabId);
    }
  });

  window.addEventListener("popstate", (e) => {
    const tabId = (e.state && e.state.tabId) || "dashboard";
    if (tabId === "dashboard") { ensureDashboardLoaded(() => switchTo(tabId, { skipHistory: true })); return; }
    if (findTabButton(tabId)) { switchTo(tabId, { skipHistory: true }); return; }
    // Tab isn't open in this session (e.g. this is a fresh reload after
    // back/forward landed on a URL we never actually opened as a tab) —
    // a real navigation re-renders it as the initial active tab.
    window.location.href = "/function/" + encodeURIComponent(tabId);
  });

  window.LambdaExplorer.tabs = { openFunctionTab, switchTo, closeTab, executeScripts, ensureDashboardLoaded };
})();

// ============================================================
// Dashboard tab — filter, sort, the glowing logs indicator, and the
// create-function modal. Runs once per dashboard load (initial or lazy
// AJAX) via its fragment's own trailing <script> calling this.
// ============================================================
window.LambdaExplorer.initDashboardTab = function (state) {
  const table = document.getElementById("fn-table");

  // ---- filter ----
  (function initFilter() {
    const input = document.getElementById("fn-filter");
    if (!input || !table) return;
    input.addEventListener("input", () => {
      const q = input.value.trim().toLowerCase();
      table.querySelectorAll(".fn-row").forEach((row) => {
        const name = row.querySelector(".fn-name").textContent.toLowerCase();
        row.style.display = name.includes(q) ? "" : "none";
      });
    });
  })();

  // ---- sort + eager "last invoked" / glow loading ----
  (function initSort() {
    if (!table) return;
    const tbody = table.querySelector("tbody");
    const headers = Array.from(table.querySelectorAll("th.sortable"));
    let currentKey = null;
    let currentDir = "asc";
    const DAY_MS = 24 * 60 * 60 * 1000;

    function rows() { return Array.from(tbody.querySelectorAll("tr")); }
    function isChecked(row) { return row.dataset.lastInvokedChecked === "true"; }

    function sortRows(key, dir) {
      const sorted = rows().sort((a, b) => {
        if (key === "name") {
          const av = (a.dataset.name || "").toLowerCase();
          const bv = (b.dataset.name || "").toLowerCase();
          return dir === "asc" ? av.localeCompare(bv) : bv.localeCompare(av);
        }
        const attr = key === "lastModified" ? "lastModified" : "lastInvoked";
        const rawA = a.dataset[attr];
        const rawB = b.dataset[attr];
        const av = rawA === undefined || rawA === "" ? -Infinity : Number(rawA);
        const bv = rawB === undefined || rawB === "" ? -Infinity : Number(rawB);
        return dir === "asc" ? av - bv : bv - av;
      });
      sorted.forEach((row) => tbody.appendChild(row));
    }

    function updateIndicators() {
      headers.forEach((h) => {
        h.classList.remove("sort-asc", "sort-desc");
        if (h.dataset.sortKey === currentKey) h.classList.add(currentDir === "asc" ? "sort-asc" : "sort-desc");
      });
    }

    // Applies a fetched last-invoked timestamp to one row's cell + glow
    // indicator, and marks the row as checked so nothing re-fetches it.
    function applyResult(row, ts) {
      row.dataset.lastInvoked = ts || "";
      row.dataset.lastInvokedChecked = "true";
      const cell = row.querySelector(".cell-last-invoked");
      if (cell) cell.textContent = ts ? new Date(ts).toLocaleString() : "never";
      const indicator = row.querySelector(".logs-indicator");
      if (indicator) {
        indicator.classList.remove("checking");
        const recent = !!ts && (Date.now() - ts) <= DAY_MS;
        indicator.classList.toggle("has-recent-logs", recent);
        indicator.title = recent
          ? "Logs within the last 24 hours — click to view"
          : ts ? "Last logged more than 24 hours ago — click to view" : "No logs yet (never invoked) — click to view";
      }
    }

    // On-demand, one row at a time — triggered by clicking that row, not
    // automatically for the whole table on page load (which is exactly
    // the "page hangs on load" problem this replaces: with a lot of
    // functions, firing a CloudWatch call for every single one up front
    // is slow and mostly wasted on rows nobody's about to look at).
    function checkRow(row) {
      if (isChecked(row) || row.dataset.lastInvokedLoading === "true") return;
      row.dataset.lastInvokedLoading = "true";
      const indicator = row.querySelector(".logs-indicator");
      if (indicator) indicator.classList.add("checking");
      const cell = row.querySelector(".cell-last-invoked");
      if (cell) cell.textContent = "checking…";
      const url = state.lastInvokedUrlTemplate.replace("__NAME__", encodeURIComponent(row.dataset.name));
      fetch(url)
        .then((r) => r.json())
        .then((data) => applyResult(row, data.last_invoked))
        .catch(() => {
          if (cell) cell.textContent = "—";
          if (indicator) indicator.classList.remove("checking");
        })
        .finally(() => { row.dataset.lastInvokedLoading = "false"; });
    }

    // Only needed to sort by "Last invoked" — has to know every row's
    // value first, so this is the one place that still checks several
    // rows at once (skipping any already checked from a row click).
    function checkAllForSort(done) {
      const pending = rows().filter((r) => !isChecked(r) && r.dataset.lastInvokedLoading !== "true");
      if (!pending.length) { done(); return; }

      const header = headers.find((h) => h.dataset.sortKey === "lastInvoked");
      const originalLabel = header ? header.textContent : null;
      if (header) header.textContent = "Last invoked (loading…)";

      const concurrency = 6;
      let nextIndex = 0;
      let remaining = pending.length;

      function fetchOne() {
        if (nextIndex >= pending.length) return;
        const row = pending[nextIndex++];
        row.dataset.lastInvokedLoading = "true";
        const indicator = row.querySelector(".logs-indicator");
        if (indicator) indicator.classList.add("checking");
        const url = state.lastInvokedUrlTemplate.replace("__NAME__", encodeURIComponent(row.dataset.name));
        fetch(url)
          .then((r) => r.json())
          .then((data) => applyResult(row, data.last_invoked))
          .catch(() => {
            const cell = row.querySelector(".cell-last-invoked");
            if (cell) cell.textContent = "—";
            if (indicator) indicator.classList.remove("checking");
          })
          .finally(() => {
            row.dataset.lastInvokedLoading = "false";
            remaining--;
            if (remaining <= 0) {
              if (header) header.textContent = originalLabel;
              done();
            } else {
              fetchOne();
            }
          });
      }

      for (let i = 0; i < Math.min(concurrency, pending.length); i++) fetchOne();
    }

    headers.forEach((h) => {
      h.addEventListener("click", () => {
        const key = h.dataset.sortKey;
        if (currentKey === key) {
          currentDir = currentDir === "asc" ? "desc" : "asc";
        } else {
          currentKey = key;
          currentDir = key === "name" ? "asc" : "desc";
        }
        if (key === "lastInvoked") {
          checkAllForSort(() => { sortRows(key, currentDir); updateIndicators(); });
        } else {
          sortRows(key, currentDir);
          updateIndicators();
        }
      });
    });

    // Clicking anywhere in a row checks that row specifically — including
    // clicking the name/logs-icon/"View source" links, which also
    // navigate to open the function's tab; the check still completes and
    // is there waiting if you come back to the dashboard tab afterward.
    tbody.addEventListener("click", (e) => {
      const row = e.target.closest(".fn-row");
      if (row) checkRow(row);
    });
  })();

  // ---- create-function modal ----
  (function initCreateModal() {
    const openBtn = document.getElementById("btn-create-function");
    const modal = document.getElementById("create-modal");
    if (!openBtn || !modal) return;

    const closeBtn = document.getElementById("create-modal-close");
    const cancelBtn = document.getElementById("create-cancel");
    const submitBtn = document.getElementById("create-submit");
    const errorBox = document.getElementById("create-error");

    const nameInput = document.getElementById("create-fn-name");
    const runtimeSelect = document.getElementById("create-runtime");
    const runtimeCustomWrap = document.getElementById("create-runtime-custom-wrap");
    const runtimeCustomInput = document.getElementById("create-runtime-custom");
    const handlerInput = document.getElementById("create-handler");
    const roleInput = document.getElementById("create-role-arn");

    const tabs = Array.from(modal.querySelectorAll(".create-tab"));
    const panelCode = document.getElementById("create-tab-code");
    const panelUpload = document.getElementById("create-tab-upload");
    const codeTextarea = document.getElementById("create-code-textarea");
    const fileInput = document.getElementById("create-code-file");

    let cmEditor = null;
    let activeTab = "code";

    function ensureEditor() {
      if (cmEditor || typeof window.CodeMirror === "undefined") return;
      cmEditor = window.CodeMirror.fromTextArea(codeTextarea, {
        mode: "python", theme: "monokai", lineNumbers: true,
        indentUnit: 4, tabSize: 4, indentWithTabs: false, viewportMargin: Infinity,
      });
    }
    function getCode() {
      if (cmEditor) return cmEditor.getValue();
      return codeTextarea ? codeTextarea.value : "";
    }
    function showError(msg) { errorBox.textContent = msg; errorBox.classList.remove("hidden"); }
    function clearError() { errorBox.textContent = ""; errorBox.classList.add("hidden"); }

    function resetForm() {
      nameInput.value = "";
      handlerInput.value = "";
      roleInput.value = "";
      runtimeSelect.value = "python3.13";
      runtimeCustomWrap.classList.add("hidden");
      runtimeCustomInput.value = "";
      if (cmEditor) cmEditor.setValue("");
      else codeTextarea.value = "";
      if (fileInput) fileInput.value = "";
      switchTab("code");
      clearError();
      submitBtn.disabled = false;
      submitBtn.textContent = "Create function";
    }

    function openModal() {
      modal.classList.remove("hidden");
      clearError();
      ensureEditor();
      if (cmEditor) setTimeout(() => cmEditor.refresh(), 0);
      nameInput.focus();
    }
    function closeModal() { modal.classList.add("hidden"); }

    function switchTab(tab) {
      activeTab = tab;
      tabs.forEach((t) => t.classList.toggle("active", t.dataset.tab === tab));
      panelCode.classList.toggle("hidden", tab !== "code");
      panelUpload.classList.toggle("hidden", tab !== "upload");
      if (tab === "code" && cmEditor) setTimeout(() => cmEditor.refresh(), 0);
    }

    tabs.forEach((t) => t.addEventListener("click", () => switchTab(t.dataset.tab)));

    runtimeSelect.addEventListener("change", () => {
      const isOther = runtimeSelect.value === "__other__";
      runtimeCustomWrap.classList.toggle("hidden", !isOther);
      if (isOther) runtimeCustomInput.focus();
    });

    openBtn.addEventListener("click", openModal);
    if (closeBtn) closeBtn.addEventListener("click", closeModal);
    if (cancelBtn) cancelBtn.addEventListener("click", closeModal);
    modal.addEventListener("click", (e) => { if (e.target === modal) closeModal(); });
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && !modal.classList.contains("hidden")) closeModal();
    });

    submitBtn.addEventListener("click", () => {
      clearError();
      const name = nameInput.value.trim();
      const handler = handlerInput.value.trim();
      const roleArn = roleInput.value.trim();
      const runtime = runtimeSelect.value === "__other__" ? runtimeCustomInput.value.trim() : runtimeSelect.value;

      if (!name) { showError("Function name is required."); return; }
      if (!handler) { showError("Handler is required."); return; }
      if (!runtime) { showError("Runtime is required."); return; }
      if (!roleArn) { showError("Execution role ARN is required — Lambda won't create a function without one."); return; }

      const fd = new FormData();
      fd.append("function_name", name);
      fd.append("handler", handler);
      fd.append("runtime", runtime);
      fd.append("role_arn", roleArn);
      fd.append("mode", activeTab);

      if (activeTab === "upload") {
        const file = fileInput.files[0];
        if (!file) { showError("Choose a file to upload first."); return; }
        fd.append("code_file", file);
      } else {
        const code = getCode();
        if (!code.trim()) { showError("Type some code first."); return; }
        fd.append("code_text", code);
      }

      submitBtn.disabled = true;
      submitBtn.textContent = "Creating…";

      fetch(state.createFunctionUrl, { method: "POST", body: fd })
        .then((r) => r.json())
        .then((data) => {
          submitBtn.disabled = false;
          submitBtn.textContent = "Create function";
          if (!data.ok) { showError(data.message || "Couldn't create the function."); return; }
          closeModal();
          window.LambdaExplorer.tabs.openFunctionTab(data.function_name);
        })
        .catch(() => {
          submitBtn.disabled = false;
          submitBtn.textContent = "Create function";
          showError("Couldn't reach the server.");
        });
    });

    resetForm();
  })();
};

// ============================================================
// Function tab — file tree, click-to-decompile .dll rows, the code
// panel, download / AI-scan / edit / deploy, and the logs panel. Called
// once per opened function tab, scoped to that tab's own container so
// several can be open at once without colliding.
// ============================================================
window.LambdaExplorer.initFunctionTab = function (tabId, state) {
  const root = document.querySelector('.tab-panel[data-tab-id="' + cssEscape(tabId) + '"]');
  if (!root) return;

  const treeEl = root.querySelector("#file-tree");
  if (!treeEl) return; // image-based function — no tree/editor to wire up

  const codePanel = root.querySelector("#code-panel");
  const statusFile = root.querySelector("#status-file");
  const toolbarPath = root.querySelector("#code-toolbar-path");
  const downloadBtn = root.querySelector("#btn-download-file");
  const scanBtn = root.querySelector("#btn-scan-ai");
  const scanAllBtn = root.querySelector("#btn-scan-all");
  const editBtn = root.querySelector("#btn-edit-file");
  const buildBtn = root.querySelector("#btn-build-review");

  const aiPanel = root.querySelector("#ai-panel");
  const aiPanelFile = root.querySelector("#ai-panel-file");
  const aiPanelBody = root.querySelector("#ai-panel-body");
  const aiPanelClose = root.querySelector("#ai-panel-close");

  const deployPanel = root.querySelector("#deploy-panel");
  const deployPanelFile = root.querySelector("#deploy-panel-file");
  const deployPanelBody = root.querySelector("#deploy-panel-body");
  const deployPanelClose = root.querySelector("#deploy-panel-close");

  const runtimeBanner = root.querySelector("#runtime-error-banner");
  const decompileLog = root.querySelector("#decompile-log");
  const decompileLogList = root.querySelector("#decompile-log-list");

  const sidebar = root.querySelector(".sidebar");
  const sidebarToggle = root.querySelector(".sidebar-collapse-btn");

  let activeLink = null;
  let currentPath = state.initialPath || null;
  let runtimeBroken = false;
  let editing = false;
  let lastReadHtml = null;

  function setEditingFlag(value) {
    editing = value;
    root.dataset.editing = value ? "true" : "false";
  }

  // ---- mobile sidebar toggle ----
  if (sidebarToggle && sidebar) {
    sidebarToggle.addEventListener("click", () => sidebar.classList.toggle("sidebar--collapsed"));
  }

  // ---- file tree rendering ----

  function iconFor(name, isDir) {
    if (isDir) return "▸";
    if (name.toLowerCase().endsWith(".dll")) return "📦";
    if (name.endsWith(".py")) return "🐍";
    if (name.endsWith(".cs")) return "🔷";
    if (name.endsWith(".json")) return "{}";
    return "▪";
  }
  function isDll(name) { return name.toLowerCase().endsWith(".dll"); }

  function renderNode(node, container, depth) {
    if (node.type === "dir") {
      if (depth > 0) {
        const dirRow = document.createElement("div");
        dirRow.className = "tree-row tree-row--dir";
        dirRow.style.paddingLeft = (depth * 14) + "px";
        dirRow.textContent = iconFor(node.name, true) + " " + node.name;
        const childWrap = document.createElement("div");
        childWrap.className = "tree-children";
        dirRow.addEventListener("click", () => {
          childWrap.classList.toggle("collapsed");
          dirRow.classList.toggle("collapsed");
        });
        container.appendChild(dirRow);
        container.appendChild(childWrap);
        (node.children || []).forEach((child) => renderNode(child, childWrap, depth + 1));
      } else {
        (node.children || []).forEach((child) => renderNode(child, container, depth));
      }
      return;
    }

    if (state.kind === "dotnet" && isDll(node.name)) {
      renderDllRow(node, container, depth);
      return;
    }

    const fileRow = document.createElement("a");
    fileRow.className = "tree-row tree-row--file";
    fileRow.style.paddingLeft = (depth * 14) + "px";
    fileRow.textContent = iconFor(node.name, false) + " " + node.name;
    fileRow.href = "javascript:void(0)";
    fileRow.dataset.path = node.path;
    fileRow.addEventListener("click", () => openFile(node.path, fileRow));
    container.appendChild(fileRow);
  }

  // ---- .dll rows: click to decompile, on demand, one at a time ------

  function renderDllRow(node, container, depth) {
    const row = document.createElement("div");
    row.className = "tree-row tree-row--dll";
    row.style.paddingLeft = (depth * 14) + "px";
    row.dataset.path = node.path;
    setDllRowLabel(row, node.name, "idle");

    const childWrap = document.createElement("div");
    childWrap.className = "tree-children collapsed";
    container.appendChild(row);
    container.appendChild(childWrap);

    let decompiled = false;

    row.addEventListener("click", () => {
      if (!confirmDiscardEdit()) return;
      if (decompiled) {
        childWrap.classList.toggle("collapsed");
        row.classList.toggle("collapsed");
        return;
      }
      if (row.dataset.state === "loading") return;
      if (runtimeBroken) { flashRowMessage(row, "Runtime is broken — see the banner above."); return; }
      if (state.ilspyMissing) { flashRowMessage(row, "ilspycmd isn't installed — see the banner above."); return; }
      runDecompile(node, row, childWrap, depth, (ok) => { decompiled = ok; });
    });
  }

  function setDllRowLabel(row, name, mode) {
    row.dataset.state = mode;
    let suffix = "", icon = "📦";
    if (mode === "loading") { icon = "⏳"; suffix = " — decompiling…"; }
    else if (mode === "ok") { suffix = " — decompiled"; }
    else if (mode === "fail") { suffix = " — failed"; }
    row.textContent = icon + " " + name + suffix;
    row.classList.toggle("tree-row--dll-fail", mode === "fail");
  }

  function flashRowMessage(row, message) {
    const original = row.textContent;
    row.title = message;
    row.textContent = "⚠ " + message;
    setTimeout(() => { row.textContent = original; }, 2200);
  }

  function runDecompile(node, row, childWrap, depth, done) {
    setDllRowLabel(row, node.name, "loading");
    fetch(state.decompileUrl + "?path=" + encodeURIComponent(node.path))
      .then((r) => r.json())
      .then((data) => {
        if (data.runtime_error) {
          runtimeBroken = true;
          setDllRowLabel(row, node.name, "fail");
          row.title = data.message || "The .NET runtime failed to start.";
          showRuntimeBanner(data.message);
          logActivity(node.path, false, "the .NET runtime failed to start — see the banner above");
          done(false);
          return;
        }
        if (!data.ok) {
          setDllRowLabel(row, node.name, "fail");
          row.title = data.message || "Decompile failed.";
          logActivity(node.path, false, data.message || "decompile failed");
          done(false);
          return;
        }
        setDllRowLabel(row, node.name, "ok");
        childWrap.classList.remove("collapsed");
        row.classList.remove("collapsed");
        (data.tree.children || []).forEach((child) => renderNode(child, childWrap, depth + 1));
        logActivity(node.path, true, data.message);

        const firstFile = firstFileIn(data.tree);
        if (firstFile) {
          const link = childWrap.querySelector('[data-path="' + cssEscape(firstFile) + '"]');
          openFile(firstFile, link || null);
        }
        done(true);
      })
      .catch(() => {
        setDllRowLabel(row, node.name, "fail");
        row.title = "Couldn't reach the decompile endpoint.";
        logActivity(node.path, false, "couldn't reach the decompile endpoint");
        done(false);
      });
  }

  function firstFileIn(node) {
    if (node.type === "file") return node.path;
    for (const child of node.children || []) {
      const found = firstFileIn(child);
      if (found) return found;
    }
    return null;
  }

  function showRuntimeBanner(message) {
    if (!runtimeBanner) return;
    runtimeBanner.innerHTML =
      '<strong>The .NET runtime failed to start</strong>, so nothing can be decompiled on this host — ' +
      "this isn't about any particular assembly, it's <code>ilspycmd</code> itself failing to launch. " +
      "The raw package is still browsable and downloadable above." +
      '<details class="banner-details"><summary>Show the underlying error</summary>' +
      '<pre class="banner-pre">' + escapeHtml(message) + "</pre></details>" +
      "Common causes: a 32-bit <code>dotnet</code> being picked up instead of 64-bit, or a virtual-memory " +
      "quota enforced on the process (sandboxing, a locked-down machine, a memory-limited VM/container). " +
      "Run <code>dotnet --version</code> in the same shell to confirm whether it's system-wide.";
    runtimeBanner.classList.remove("hidden");
  }

  function logActivity(path, ok, message) {
    if (!decompileLog || !decompileLogList) return;
    decompileLog.classList.remove("hidden");
    decompileLog.open = true;
    const li = document.createElement("li");
    li.className = ok ? "ok" : "fail";
    const pathSpan = document.createElement("span");
    pathSpan.className = "mono";
    pathSpan.textContent = path;
    li.appendChild(pathSpan);
    li.appendChild(document.createTextNode(" — " + message));
    decompileLogList.appendChild(li);
  }

  // ---- toolbar (download / scan / edit) -----------------------------

  function updateToolbar(path, isBinary) {
    currentPath = path;
    if (toolbarPath) toolbarPath.textContent = path;
    if (downloadBtn) {
      downloadBtn.href = state.downloadFileUrl + "?path=" + encodeURIComponent(path);
      downloadBtn.classList.remove("btn--disabled");
    }
    if (scanBtn) {
      scanBtn.disabled = !!isBinary;
      scanBtn.classList.toggle("btn--disabled", !!isBinary);
      scanBtn.title = isBinary ? "Can't scan a binary file." : "";
    }
    if (editBtn) {
      editBtn.disabled = !!isBinary;
      editBtn.classList.toggle("btn--disabled", !!isBinary);
      editBtn.title = isBinary ? "Can't edit a binary file." : "";
    }
  }

  // ---- code panel -----------------------------------------------

  function openFile(path, linkEl) {
    if (!confirmDiscardEdit()) return;
    if (activeLink) activeLink.classList.remove("active");
    if (linkEl) { linkEl.classList.add("active"); activeLink = linkEl; }
    codePanel.innerHTML = '<div class="empty-editor"><div class="empty-cursor">_</div><p>Loading…</p></div>';
    fetch(state.fileUrl + "?path=" + encodeURIComponent(path))
      .then((r) => r.json())
      .then((data) => {
        if (data.error) {
          codePanel.innerHTML = '<div class="empty-editor"><p>' + escapeHtml(data.error) + "</p></div>";
          updateToolbar(path, true);
          return;
        }
        if (data.binary) {
          codePanel.innerHTML = '<div class="empty-editor"><p>Binary file — not shown here. Download it instead.</p></div>';
          updateToolbar(path, true);
        } else {
          codePanel.innerHTML = data.html;
          updateToolbar(path, false);
        }
        if (statusFile) statusFile.textContent = path;
        // On mobile, picking a file is the moment to get the sidebar out
        // of the way so the code is actually visible.
        if (sidebar && window.innerWidth <= 860) sidebar.classList.add("sidebar--collapsed");
      })
      .catch(() => {
        codePanel.innerHTML = '<div class="empty-editor"><p>Couldn\'t load that file.</p></div>';
      });
  }

  // ---- AI review panel --------------------------------------------

  function severityRank(sev) {
    const order = { critical: 0, high: 1, medium: 2, low: 3 };
    const r = order[(sev || "").toLowerCase()];
    return r === undefined ? 4 : r;
  }

  function renderScanResult(data) {
    if (data.error) {
      const helpful = data.error === "no_api_key" || data.error === "not_installed";
      aiPanelBody.innerHTML =
        '<div class="ai-message ' + (helpful ? "ai-message--info" : "ai-message--error") + '">' +
        escapeHtml(data.message || "Something went wrong running the review.") + "</div>";
      return;
    }

    const isFunctionScope = data.overview !== undefined;
    const vulns = (data.vulnerabilities || []).slice().sort((a, b) => severityRank(a.severity) - severityRank(b.severity));
    const providerLabel = data.provider === "deepseek" ? "DeepSeek" : data.provider === "anthropic" ? "Anthropic" : "AI";

    let html = '<div class="ai-disclaimer">' + providerLabel + "-generated " +
      (isFunctionScope ? "whole-function review — a fast first pass across every Python file included" : "review — a fast first pass") +
      ", not a substitute for a real audit.</div>";

    if (isFunctionScope) {
      html += '<div class="ai-summary"><h4>Function overview</h4><p>' + escapeHtml(data.overview || "—") + "</p></div>";
    } else {
      html += '<div class="ai-summary"><h4>What this file does</h4><p>' + escapeHtml(data.summary || "—") + "</p></div>";
    }

    html += '<div class="ai-vulns"><h4>Security review';
    html += vulns.length ? " — " + vulns.length + " finding" + (vulns.length === 1 ? "" : "s") : "";
    html += "</h4>";

    if (!vulns.length) {
      html += '<div class="ai-message ai-message--ok">No obvious vulnerabilities found' + (isFunctionScope ? " across the reviewed files." : " in this file.") + "</div>";
    } else {
      vulns.forEach((v) => {
        const sev = (v.severity || "low").toLowerCase();
        html +=
          '<div class="vuln-card vuln-card--' + escapeHtml(sev) + '">' +
          '<div class="vuln-head"><span class="pill pill--sev-' + escapeHtml(sev) + '">' + escapeHtml(sev) + "</span>" +
          (v.file ? '<span class="vuln-file mono">' + escapeHtml(v.file) + "</span>" : "") +
          '<span class="vuln-title">' + escapeHtml(v.title || "Untitled finding") + "</span></div>" +
          '<p class="vuln-desc">' + escapeHtml(v.description || "") + "</p>" +
          (v.recommendation ? '<p class="vuln-fix"><strong>Fix:</strong> ' + escapeHtml(v.recommendation) + "</p>" : "") +
          "</div>";
      });
    }
    html += "</div>";

    if (isFunctionScope && data.included_files && data.included_files.length) {
      const scopeNote = data.traced_from_imports
        ? "traced from the handler's own imports — vendored dependencies excluded"
        : "import tracing found nothing to start from, so every .py file in the package is listed here instead";
      const batchNote = data.batch_count > 1 ? ", reviewed across " + data.batch_count + " batches run in parallel" : "";
      html += '<div class="ai-scope"><h4>Files reviewed (' + data.included_files.length + ")</h4>" +
        '<p class="muted">' + escapeHtml(scopeNote + batchNote) + "</p>" +
        '<p class="mono muted">' + data.included_files.map(escapeHtml).join(", ") + "</p></div>";
    }
    if (isFunctionScope && data.skipped_files && data.skipped_files.length) {
      html += '<div class="ai-scope"><h4>Not reviewed — over this scan\'s size budget (' + data.skipped_files.length + ")</h4><p class=\"mono muted\">" +
        data.skipped_files.map(escapeHtml).join(", ") + "</p></div>";
    }
    if (data.notes) {
      html += '<div class="ai-notes"><h4>Other notes</h4><p>' + escapeHtml(data.notes) + "</p></div>";
    }

    aiPanelBody.innerHTML = html;
  }

  function runScan() {
    if (!currentPath || !scanBtn || scanBtn.disabled) return;
    aiPanel.classList.remove("hidden");
    if (aiPanelFile) aiPanelFile.textContent = currentPath;
    aiPanelBody.innerHTML = '<div class="empty-editor"><div class="empty-cursor">_</div><p>Reviewing with AI…</p></div>';
    fetch(state.scanFileUrl + "?path=" + encodeURIComponent(currentPath))
      .then((r) => r.json())
      .then(renderScanResult)
      .catch(() => { aiPanelBody.innerHTML = '<div class="ai-message ai-message--error">Couldn\'t reach the review endpoint.</div>'; });
  }

  function runFullScan() {
    if (!scanAllBtn) return;
    aiPanel.classList.remove("hidden");
    if (aiPanelFile) aiPanelFile.textContent = "entire function (" + state.functionName + ")";
    aiPanelBody.innerHTML = '<div class="empty-editor"><div class="empty-cursor">_</div><p>Tracing imports from the handler and reviewing every file that pulls in — large functions run in several batches in parallel, so this can take a bit longer than a single-file scan…</p></div>';
    fetch(state.scanAllUrl)
      .then((r) => r.json())
      .then(renderScanResult)
      .catch(() => { aiPanelBody.innerHTML = '<div class="ai-message ai-message--error">Couldn\'t reach the review endpoint.</div>'; });
  }

  if (scanBtn) scanBtn.addEventListener("click", runScan);
  if (scanAllBtn) scanAllBtn.addEventListener("click", runFullScan);
  if (aiPanelClose) aiPanelClose.addEventListener("click", () => aiPanel.classList.add("hidden"));

  // ---- edit & deploy ------------------------------------------------

  function confirmDiscardEdit() {
    if (!editing) return true;
    if (!confirm("Discard your unsaved edits to " + currentPath + "?")) return false;
    exitEditMode();
    return true;
  }

  function enterEditMode() {
    if (!currentPath || editing || (editBtn && editBtn.disabled)) return;
    lastReadHtml = codePanel.innerHTML;
    codePanel.innerHTML = '<div class="empty-editor"><div class="empty-cursor">_</div><p>Loading…</p></div>';

    fetch(state.editOriginalUrl + "?path=" + encodeURIComponent(currentPath))
      .then((r) => r.json())
      .then((data) => {
        if (data.error) {
          codePanel.innerHTML = '<div class="empty-editor"><p>' + escapeHtml(data.error) + "</p></div>";
          return;
        }
        setEditingFlag(true);
        const ta = document.createElement("textarea");
        ta.className = "edit-textarea mono";
        ta.dataset.role = "edit-textarea";
        ta.spellcheck = false;
        ta.value = data.content;
        codePanel.innerHTML = "";
        codePanel.appendChild(ta);
        ta.focus();

        editBtn.textContent = "✕ Cancel edit";
        if (buildBtn) buildBtn.classList.remove("hidden");
        if (downloadBtn) downloadBtn.classList.add("btn--disabled");
        if (scanBtn) scanBtn.disabled = true;
      })
      .catch(() => {
        codePanel.innerHTML = '<div class="empty-editor"><p>Couldn\'t load the file for editing.</p></div>';
      });
  }

  function exitEditMode() {
    setEditingFlag(false);
    if (lastReadHtml != null) codePanel.innerHTML = lastReadHtml;
    if (editBtn) editBtn.textContent = "✎ Edit";
    if (buildBtn) buildBtn.classList.add("hidden");
    if (downloadBtn) downloadBtn.classList.remove("btn--disabled");
    if (scanBtn) scanBtn.disabled = false;
  }

  function showDeployPanel() { if (deployPanel) deployPanel.classList.remove("hidden"); }
  function hideDeployPanel() { if (deployPanel) deployPanel.classList.add("hidden"); }

  function renderDiffBlock(diff) {
    if (!diff) return "";
    const lines = diff.split("\n").map((line) => {
      let cls = "diff-ctx";
      if (line.startsWith("+++") || line.startsWith("---")) cls = "diff-file";
      else if (line.startsWith("+")) cls = "diff-add";
      else if (line.startsWith("-")) cls = "diff-del";
      else if (line.startsWith("@@")) cls = "diff-hunk";
      return '<div class="' + cls + '">' + escapeHtml(line || " ") + "</div>";
    });
    return '<div class="diff-wrap"><h4>Changes</h4><div class="diff-block mono">' + lines.join("") + "</div></div>";
  }

  function startBuildReview() {
    const ta = root.querySelector('[data-role="edit-textarea"]');
    if (!ta) return;
    const content = ta.value;

    showDeployPanel();
    if (deployPanelFile) deployPanelFile.textContent = currentPath;
    deployPanelBody.innerHTML =
      '<div class="empty-editor"><div class="empty-cursor">_</div><p>' +
      (state.kind === "dotnet" ? "Preparing deployment — compiling…" : "Preparing deployment…") + "</p></div>";

    fetch(state.deployPrepareUrl, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ path: currentPath, content: content }),
    })
      .then((r) => r.json())
      .then(renderPrepareResult)
      .catch(() => { deployPanelBody.innerHTML = '<div class="ai-message ai-message--error">Couldn\'t reach the deploy endpoint.</div>'; });
  }

  function renderPrepareResult(data) {
    if (!data.ok) {
      let html = '<div class="ai-message ai-message--error">' + escapeHtml(data.message || "Couldn't prepare the deployment.") + "</div>";
      if (data.build_log) {
        html += '<div class="build-log-wrap"><h4>Build output</h4><pre class="banner-pre build-log">' + escapeHtml(data.build_log) + "</pre></div>";
      }
      html += renderDiffBlock(data.diff);
      html += '<div class="deploy-actions"><button class="btn btn--ghost btn--sm" type="button" data-role="deploy-back-to-edit">← Back to edit</button></div>';
      deployPanelBody.innerHTML = html;
      const back = deployPanelBody.querySelector('[data-role="deploy-back-to-edit"]');
      if (back) back.addEventListener("click", hideDeployPanel);
      return;
    }

    const stagedId = data.staged_id;
    let html = '<div class="banner banner--warning deploy-warning">';
    html += "<strong>This will overwrite the live code for <code>" + escapeHtml(state.functionName) + "</code> immediately.</strong> ";
    html += "There's no automatic version history here — a one-click rollback to whatever's live right now will appear after this deploy, for this session only.";
    html += "</div>";
    html += renderDiffBlock(data.diff);
    html += '<div class="confirm-gate">';
    html += '<label for="deploy-confirm-input-' + cssEscape(tabId) + '">Type the function name (<span class="mono">' + escapeHtml(state.functionName) + '</span>) to confirm:</label>';
    html += '<input type="text" id="deploy-confirm-input-' + cssEscape(tabId) + '" class="confirm-input mono" data-role="deploy-confirm-input" autocomplete="off">';
    html += '<button class="btn btn--accent btn--sm" type="button" data-role="deploy-go-btn" disabled>🚀 Deploy to AWS Lambda</button>';
    html += "</div>";
    deployPanelBody.innerHTML = html;

    const input = deployPanelBody.querySelector('[data-role="deploy-confirm-input"]');
    const goBtn = deployPanelBody.querySelector('[data-role="deploy-go-btn"]');
    input.addEventListener("input", () => { goBtn.disabled = input.value.trim() !== state.functionName; });
    goBtn.addEventListener("click", () => {
      if (!confirm('Deploy this edit to "' + state.functionName + '" right now? This immediately replaces the live code.')) return;
      runDeploy(stagedId, input.value.trim());
    });
  }

  function runDeploy(stagedId, confirmText) {
    deployPanelBody.innerHTML = '<div class="empty-editor"><div class="empty-cursor">_</div><p>Deploying…</p></div>';
    fetch(state.deployConfirmUrl, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ staged_id: stagedId, confirm_text: confirmText }),
    })
      .then((r) => r.json())
      .then(renderDeployResult)
      .catch(() => { deployPanelBody.innerHTML = '<div class="ai-message ai-message--error">Couldn\'t reach the deploy endpoint.</div>'; });
  }

  function renderDeployResult(data) {
    if (!data.ok) {
      deployPanelBody.innerHTML = '<div class="ai-message ai-message--error">' + escapeHtml(data.message || "Deploy failed.") + "</div>";
      return;
    }
    let html = '<div class="ai-message ai-message--ok">Deployed. New code hash: <span class="mono">' + escapeHtml(data.new_code_sha || "—") + "</span></div>";
    if (data.rollback_available) {
      html += '<div class="deploy-actions"><button class="btn btn--ghost btn--sm" type="button" data-role="deploy-rollback-btn">⏪ Rollback to previous code</button></div>';
    }
    html += '<p class="muted deploy-reload-hint">Close and reopen this tab to browse the newly deployed code.</p>';
    deployPanelBody.innerHTML = html;

    setEditingFlag(false);
    lastReadHtml = null;
    codePanel.innerHTML = '<div class="empty-editor"><div class="empty-cursor">_</div><p>Deployed — close and reopen this tab to browse the new code.</p></div>';
    if (editBtn) editBtn.textContent = "✎ Edit";
    if (buildBtn) buildBtn.classList.add("hidden");
    if (downloadBtn) downloadBtn.classList.remove("btn--disabled");
    if (scanBtn) scanBtn.disabled = false;

    const rb = deployPanelBody.querySelector('[data-role="deploy-rollback-btn"]');
    if (rb) rb.addEventListener("click", runRollback);
  }

  function runRollback() {
    if (!confirm('Roll back "' + state.functionName + '" to the code that was live before this deploy?')) return;
    deployPanelBody.innerHTML = '<div class="empty-editor"><div class="empty-cursor">_</div><p>Rolling back…</p></div>';
    fetch(state.deployRollbackUrl, { method: "POST" })
      .then((r) => r.json())
      .then((data) => {
        if (!data.ok) {
          deployPanelBody.innerHTML = '<div class="ai-message ai-message--error">' + escapeHtml(data.message || "Rollback failed.") + "</div>";
          return;
        }
        deployPanelBody.innerHTML =
          '<div class="ai-message ai-message--ok">Rolled back. Code hash restored to: <span class="mono">' +
          escapeHtml(data.new_code_sha || "—") + '</span></div><p class="muted deploy-reload-hint">Close and reopen this tab to browse the restored code.</p>';
      })
      .catch(() => { deployPanelBody.innerHTML = '<div class="ai-message ai-message--error">Couldn\'t reach the rollback endpoint.</div>'; });
  }

  if (editBtn) {
    editBtn.addEventListener("click", () => {
      if (editing) { confirmDiscardEdit(); return; }
      enterEditMode();
    });
  }
  if (buildBtn) buildBtn.addEventListener("click", startBuildReview);
  if (deployPanelClose) deployPanelClose.addEventListener("click", hideDeployPanel);

  // Covers the gaps confirmDiscardEdit()/tab-close can't: the browser
  // back button or closing the whole tab/window.
  window.addEventListener("beforeunload", (e) => {
    if (!editing) return;
    e.preventDefault();
    e.returnValue = "";
  });

  // ---- logs panel -----------------------------------------------

  (function initLogs() {
    const btn = root.querySelector("#btn-view-logs");
    const panel = root.querySelector("#logs-panel");
    const body = root.querySelector("#logs-panel-body");
    const closeBtn = root.querySelector("#logs-panel-close");
    const refreshBtn = root.querySelector("#logs-refresh");
    if (!btn || !panel || !body) return;

    function formatTimestamp(ms) {
      try { return new Date(ms).toLocaleString(); } catch (e) { return String(ms); }
    }
    function classifyLine(msg) {
      if (/^(START|END|REPORT) RequestId:/.test(msg)) return "log-line--meta";
      if (/error|exception|traceback/i.test(msg)) return "log-line--error";
      return "";
    }
    function renderLogs(data) {
      if (data.error) {
        body.innerHTML = '<div class="ai-message ai-message--error">' + escapeHtml(data.error) + "</div>";
        return;
      }
      const events = data.events || [];
      if (!events.length) {
        body.innerHTML = '<div class="ai-message ai-message--info">No recent log events found — this function may not have run recently.</div>';
        return;
      }
      let html = '<div class="log-lines">';
      events.forEach((e) => {
        const cls = classifyLine(e.message);
        html += '<div class="log-line ' + cls + '"><span class="log-ts mono">' + escapeHtml(formatTimestamp(e.timestamp)) +
          '</span><span class="log-msg mono">' + escapeHtml((e.message || "").replace(/\n$/, "")) + "</span></div>";
      });
      html += "</div>";
      body.innerHTML = html;
      body.scrollTop = body.scrollHeight;
    }
    function loadLogs() {
      panel.classList.remove("hidden");
      body.innerHTML = '<div class="empty-editor"><div class="empty-cursor">_</div><p>Fetching logs…</p></div>';
      fetch(state.logsUrl)
        .then((r) => r.json())
        .then(renderLogs)
        .catch(() => { body.innerHTML = '<div class="ai-message ai-message--error">Couldn\'t reach the logs endpoint.</div>'; });
    }

    btn.addEventListener("click", loadLogs);
    if (refreshBtn) refreshBtn.addEventListener("click", loadLogs);
    if (closeBtn) closeBtn.addEventListener("click", () => panel.classList.add("hidden"));

    if (state.autoOpenLogs) loadLogs();
  })();

  // ---- init ---------------------------------------------------------

  renderNode(state.tree, treeEl, 0);

  if (state.initialPath) {
    const link = treeEl.querySelector('[data-path="' + cssEscape(state.initialPath) + '"]');
    if (link) { link.classList.add("active"); activeLink = link; }
    updateToolbar(state.initialPath, false);
  }
};
