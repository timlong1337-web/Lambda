"""
Lambda Explorer — browse every Lambda function in an AWS account, read
Python source directly, and auto-decompile + read C#/.NET source.

Run:
    pip install -r requirements.txt
    python app.py

See README.md for the .NET decompiler prerequisite and security notes
before pointing this at a real AWS account.
"""
import os
import io
import zipfile
import functools

from flask import (
    Flask, render_template, request, redirect, url_for, session,
    flash, jsonify, send_file, Response, abort
)
from flask_session import Session

from services.aws_client import build_session, verify_and_identify, CredentialError
from services.lambda_service import LambdaService, LambdaServiceError
from services import code_viewer, decompiler

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("APP_SECRET_KEY", os.urandom(24))
app.config["SESSION_TYPE"] = "filesystem"
app.config["SESSION_FILE_DIR"] = os.path.join(os.path.dirname(__file__), ".flask_session")
app.config["SESSION_PERMANENT"] = False
Session(app)

# In-memory cache of extracted/decompiled packages, keyed by
# f"{function_name}:{code_sha256}" so a redeploy invalidates it automatically.
# This intentionally lives in process memory, not in the user's browser
# session — extracted source can be large and doesn't belong in a cookie.
_PACKAGE_CACHE = {}


# --------------------------------------------------------------------------
# Auth helpers
# --------------------------------------------------------------------------

def login_required(view):
    @functools.wraps(view)
    def wrapped(*args, **kwargs):
        if "aws_creds" not in session:
            flash("Connect an AWS account first.", "warning")
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped


def get_lambda_service() -> LambdaService:
    creds = session["aws_creds"]
    boto_session = build_session(
        creds["access_key"], creds["secret_key"], creds["region"], creds.get("session_token")
    )
    return LambdaService(boto_session)


# --------------------------------------------------------------------------
# Auth routes
# --------------------------------------------------------------------------

@app.route("/", methods=["GET"])
def index():
    return redirect(url_for("dashboard") if "aws_creds" in session else url_for("login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "GET":
        return render_template("login.html")

    access_key = request.form.get("access_key", "")
    secret_key = request.form.get("secret_key", "")
    session_token = request.form.get("session_token", "")
    region = request.form.get("region", "us-east-1")

    try:
        boto_session = build_session(access_key, secret_key, region, session_token or None)
        identity = verify_and_identify(boto_session)
    except CredentialError as e:
        flash(str(e), "error")
        return render_template("login.html", region=region), 400

    session["aws_creds"] = {
        "access_key": access_key,
        "secret_key": secret_key,
        "session_token": session_token or None,
        "region": region,
    }
    session["identity"] = identity
    flash(f"Connected to account {identity['account']}.", "success")
    return redirect(url_for("dashboard"))


@app.route("/logout")
def logout():
    session.clear()
    flash("Disconnected.", "success")
    return redirect(url_for("login"))


# --------------------------------------------------------------------------
# Dashboard
# --------------------------------------------------------------------------

@app.route("/dashboard")
@login_required
def dashboard():
    try:
        svc = get_lambda_service()
        functions = svc.list_functions()
    except LambdaServiceError as e:
        flash(f"Couldn't list functions: {e}", "error")
        functions = []

    for f in functions:
        f["_kind"] = code_viewer.classify_runtime(f.get("Runtime", ""))

    return render_template(
        "dashboard.html",
        functions=functions,
        identity=session.get("identity", {}),
        region=session["aws_creds"]["region"],
    )


# --------------------------------------------------------------------------
# Function source viewer
# --------------------------------------------------------------------------

def _load_package(name: str, force: bool = False) -> dict:
    """
    Ensures the deployment package for `name` is downloaded, extracted, and
    (if C#) decompiled, then returns the cached bundle:
    {config, code_meta, kind, root, tree, decompile_results, is_image}
    """
    svc = get_lambda_service()
    detail = svc.get_function(name)
    config = detail.get("Configuration", {})
    code_meta = detail.get("Code", {})
    runtime = config.get("Runtime", "")
    kind = code_viewer.classify_runtime(runtime)
    code_sha = config.get("CodeSha256", "nosha")
    cache_key = f"{name}:{code_sha}"

    if not force and cache_key in _PACKAGE_CACHE:
        return _PACKAGE_CACHE[cache_key]

    if "ImageUri" in code_meta and "Location" not in code_meta:
        bundle = {
            "config": config, "code_meta": code_meta, "kind": "image",
            "root": None, "tree": None, "decompile_results": None,
        }
        _PACKAGE_CACHE[cache_key] = bundle
        return bundle

    zip_bytes = LambdaService.download_package(code_meta["Location"])
    root = code_viewer.extract_zip(zip_bytes)
    decompile_results = None

    if kind == "dotnet":
        if decompiler.is_available():
            result = decompiler.decompile_all(root)
            # Merge the decompiled .cs output into the same tree the user
            # browses, under a top-level folder, alongside the raw package.
            merged_root = result["output_dir"]
            decompile_results = result["results"]
            root = _merge_dirs(original=root, decompiled=merged_root)
        else:
            decompile_results = []

    tree = code_viewer.build_tree(root)
    bundle = {
        "config": config, "code_meta": code_meta, "kind": kind,
        "root": root, "tree": tree, "decompile_results": decompile_results,
    }
    _PACKAGE_CACHE[cache_key] = bundle
    return bundle


def _merge_dirs(original: str, decompiled: str) -> str:
    """
    Builds a single virtual root containing two subfolders: the raw
    extracted package and the decompiled source, so both are browsable
    from one file tree. Uses symlinks to avoid copying large trees.
    """
    import tempfile
    combined = tempfile.mkdtemp(prefix="combined_")
    os.symlink(original, os.path.join(combined, "package (raw)"))
    os.symlink(decompiled, os.path.join(combined, "decompiled source"))
    return combined


@app.route("/function/<name>")
@login_required
def view_function(name):
    try:
        bundle = _load_package(name)
    except LambdaServiceError as e:
        flash(f"Couldn't load {name}: {e}", "error")
        return redirect(url_for("dashboard"))
    except Exception as e:
        flash(f"Couldn't prepare {name} for viewing: {e}", "error")
        return redirect(url_for("dashboard"))

    default_path = None
    default_html = None
    if bundle["kind"] != "image":
        preferred_ext = [".py"] if bundle["kind"] == "python" else [".cs"]
        candidates = code_viewer.find_files(bundle["root"], preferred_ext)
        default_path = code_viewer.pick_default_file(candidates, handler=bundle["config"].get("Handler"))
        if default_path:
            text = code_viewer.read_text_file(bundle["root"], default_path)
            default_html = code_viewer.highlight_code(text, filename=default_path)

    ilspy_missing = bundle["kind"] == "dotnet" and not decompiler.is_available()

    return render_template(
        "view_function.html",
        name=name,
        config=bundle["config"],
        kind=bundle["kind"],
        tree=bundle["tree"],
        decompile_results=bundle["decompile_results"],
        ilspy_missing=ilspy_missing,
        default_path=default_path,
        default_html=default_html,
        is_image=(bundle["kind"] == "image"),
        code_meta=bundle["code_meta"],
    )


@app.route("/function/<name>/file")
@login_required
def get_file(name):
    path = request.args.get("path", "")
    try:
        bundle = _load_package(name)
    except Exception as e:
        return jsonify({"error": str(e)}), 400

    if bundle["kind"] == "image" or not bundle["root"]:
        return jsonify({"error": "This function has no browsable package."}), 400

    if not code_viewer.is_probably_text(bundle["root"], path):
        return jsonify({"binary": True, "path": path})

    try:
        text = code_viewer.read_text_file(bundle["root"], path)
    except FileNotFoundError:
        return jsonify({"error": "File not found."}), 404
    except ValueError:
        return jsonify({"error": "Invalid path."}), 400

    html = code_viewer.highlight_code(text, filename=path)
    return jsonify({"html": html, "path": path})


@app.route("/function/<name>/download")
@login_required
def download_package(name):
    try:
        svc = get_lambda_service()
        detail = svc.get_function(name)
        code_meta = detail.get("Code", {})
        if "Location" not in code_meta:
            flash("This function is image-based; there's no zip package to download.", "error")
            return redirect(url_for("view_function", name=name))
        zip_bytes = LambdaService.download_package(code_meta["Location"])
    except LambdaServiceError as e:
        flash(f"Couldn't download {name}: {e}", "error")
        return redirect(url_for("view_function", name=name))

    return send_file(
        io.BytesIO(zip_bytes), mimetype="application/zip",
        as_attachment=True, download_name=f"{name}.zip",
    )


@app.route("/function/<name>/download-decompiled")
@login_required
def download_decompiled(name):
    try:
        bundle = _load_package(name)
    except Exception as e:
        flash(f"Couldn't prepare {name}: {e}", "error")
        return redirect(url_for("view_function", name=name))

    if bundle["kind"] != "dotnet" or not bundle["root"]:
        flash("Decompiled download is only available for .NET functions.", "error")
        return redirect(url_for("view_function", name=name))

    decompiled_dir = os.path.join(bundle["root"], "decompiled source")
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for dirpath, _, filenames in os.walk(decompiled_dir, followlinks=True):
            for f in filenames:
                full = os.path.join(dirpath, f)
                arc = os.path.relpath(full, decompiled_dir)
                zf.write(full, arc)
    buf.seek(0)
    return send_file(
        buf, mimetype="application/zip",
        as_attachment=True, download_name=f"{name}-decompiled.zip",
    )


# --------------------------------------------------------------------------
# Assets
# --------------------------------------------------------------------------

@app.route("/assets/pygments.css")
def pygments_css():
    return Response(code_viewer.pygments_css(), mimetype="text/css")


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5050, debug=True)
