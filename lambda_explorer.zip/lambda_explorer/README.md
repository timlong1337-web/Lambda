# Lambda Explorer

A Flask app that connects to an AWS account with an access key / secret key,
lists every Lambda function, and lets you read the source straight from the
browser:

- **Python functions** — the deployment package is downloaded and unzipped,
  and every file is browsable in a VS Code-style tree + syntax-highlighted
  panel.
- **C# / .NET functions** — the package is downloaded and every managed
  `.dll` in it is **automatically decompiled** with [ILSpy](https://github.com/icsharpcode/ILSpy),
  then the resulting `.cs` source is browsable the same way, right next to
  the raw package contents.
- **Container-image functions** — flagged as such, with the image URI shown
  (there's no zip package to open in that case).

Every function page also has one-click **download the raw package** and
(for .NET) **download the decompiled source as a zip**.

## Setup

```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### C# decompilation prerequisite

Decompiling `.dll` files requires **ilspycmd**, the command-line tool for
ILSpy. It's a .NET global tool, not a Python package:

```bash
# requires the .NET SDK: https://dotnet.microsoft.com/download
dotnet tool install -g ilspycmd
```

Make sure `ilspycmd` is on the `PATH` of whatever shell runs `python app.py`.
If it isn't installed, the app still works — C# functions just show a
banner explaining that and let you download the raw package instead of
auto-decompiled source.

## Running it

```bash
python app.py
```

Then open `http://127.0.0.1:5050`, paste in an access key / secret key
(and a session token if you're using temporary STS credentials) and a
region, and connect.

The IAM identity needs, at minimum:

```json
{
  "Effect": "Allow",
  "Action": ["lambda:ListFunctions", "lambda:GetFunction"],
  "Resource": "*"
}
```

## Security notes — read before pointing this at a real account

This tool is built the way it was asked for: raw access-key/secret-key
login. A few things worth knowing about that trade-off:

- **Credentials are kept server-side**, in a `Flask-Session` filesystem
  store under `.flask_session/` next to the app — not in a browser cookie
  (a default Flask session cookie is only *signed*, not encrypted, so a
  secret key would be readable by anyone who got the cookie). Even so,
  treat `.flask_session/` as sensitive: it's plaintext on disk for as long
  as the session lives.
- **Long-lived access keys are the highest-risk form of AWS credential.**
  If you can, generate temporary credentials instead (`aws sts
  assume-role` / `get-session-token`) and paste those in along with the
  session token field — same login form, much shorter blast radius if
  they leak.
- **This app is meant to run locally or on a trusted internal host**, not
  be exposed on the open internet — anyone who can reach it can reach
  everything those AWS credentials can reach, plus the full decompiled
  source of your C# functions. There's no app-level login in front of the
  AWS login step; put it behind a VPN or add one if that's not true for
  your setup.
- Downloaded packages and decompiled source are cached **in server memory**
  for the life of the process (keyed to each function's code hash, so a
  redeploy is picked up automatically) and extracted to the OS temp
  directory. Restarting the app clears the cache; temp directories are not
  auto-deleted, so periodically clear your temp folder if you're doing
  this a lot.

## How the C# decompilation works

For each `.dll` found in the package (skipping `runtimes/` — native-asset
folders, not managed code), `ilspycmd` is run in project mode first
(`-p`, one `.cs` file per type — the closest thing to real source layout),
falling back to a single combined `.cs` file if project mode fails for
that particular assembly. Every attempt, success or failure, shows up in
the "Decompile log" on the function page, so you can see exactly which
assemblies came back as readable source and which didn't.

Decompiled output is best-effort — it's the same technique tools like
dnSpy and ILSpy's GUI use, and works well for typical managed Lambda
handlers, but variable names, comments, and some language constructs from
the original source are not recoverable from IL and won't come back
exactly as written.
