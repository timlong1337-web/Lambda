"""
Optional AI-assisted review of Lambda source: a per-file quick read, or a
comprehensive pass across every Python file the function actually imports.
Both are a fast first look, not a substitute for a real audit.

Two providers, picked on the connect page:
- DeepSeek — a plain REST call via `requests` (already a hard dependency
  of this app), so it needs no extra package installed.
- Anthropic — via the official `anthropic` Python package, same as before.
"""
import json
import os
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests

try:
    import anthropic
except ImportError:  # the app still runs without this installed — see provider_available()
    anthropic = None

PROVIDERS = ("deepseek", "anthropic")

DEEPSEEK_MODEL = os.environ.get("DEEPSEEK_MODEL", "deepseek-chat")
DEEPSEEK_API_URL = "https://api.deepseek.com/chat/completions"
ANTHROPIC_MODEL = os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-5")

MAX_CHARS = 60_000  # per-file review budget

# Whole-function review: rather than capping at some fixed file count and
# silently dropping the rest, every discovered file gets reviewed — split
# across as many batches as it takes to stay within a sane per-request
# budget, run in parallel, then merged into one report. MAX_BATCHES is
# just a sanity ceiling against a pathologically large import graph
# turning one click into dozens of paid API calls without warning.
MAX_BATCH_CHARS = 80_000
MAX_SINGLE_FILE_CHARS_IN_BATCH = 60_000
MAX_BATCHES = 8
BATCH_CONCURRENCY = 4

FILE_SYSTEM_PROMPT = """You are a careful application security reviewer looking at one file from an AWS Lambda function's deployment package (it may be original source or decompiled — decompiled code can have generic names and lost comments; review the logic itself).

Respond with ONLY a JSON object, no markdown fences, no prose outside the JSON, in exactly this shape:
{
  "summary": "2-4 sentence plain-English explanation of what this file does",
  "vulnerabilities": [
    {"title": "short name", "severity": "low|medium|high|critical", "description": "what the issue is, and where in the file", "recommendation": "how to fix it"}
  ],
  "notes": "anything else worth flagging that isn't a security issue, or empty string"
}

If you find no plausible vulnerabilities, return an empty vulnerabilities array — don't invent issues just to have something to report. Be specific and reference the actual code rather than giving generic advice."""

FUNCTION_SYSTEM_PROMPT = """You are a careful application security reviewer looking at part of the Python source of an AWS Lambda function — every file included below, together, not in isolation (there may be more files reviewed in separate batches; focus on what's in front of you). Read them as one program: trace how data flows from the handler's entry point (the `event` and `context` parameters) through any helper modules and out to external calls (databases, HTTP requests, subprocess, the file system, deserialization, etc.), and consider how the included files relate to each other.

Respond with ONLY a JSON object, no markdown fences, no prose outside the JSON, in exactly this shape:
{
  "overview": "a comprehensive multi-paragraph explanation of what these files do end-to-end, based on what's included here: entry point/handler if present, what it does step by step, what external services or resources it touches, and how the included files relate to each other",
  "vulnerabilities": [
    {"title": "short name", "severity": "low|medium|high|critical", "file": "the path of the file this finding concerns most", "description": "what the issue is and where, including a concrete scenario for how it could actually be exploited", "recommendation": "how to fix it"}
  ],
  "notes": "anything else worth flagging that isn't a security issue, or empty string"
}

Pay particular attention to: unsanitized data from the event payload reaching a dangerous sink (subprocess, eval/exec, SQL queries, file paths, deserialization of untrusted data), hardcoded secrets or credentials, SSRF opportunities, injection via string formatting, insecure temp-file handling, overly permissive assumptions about what's trustworthy, and anywhere untrusted input crosses a trust boundary between files. If you find no plausible vulnerabilities, return an empty vulnerabilities array — don't invent issues just to have something to report."""

SYNTHESIS_SYSTEM_PROMPT = """You are given several partial overviews, each describing a different subset of files from the same AWS Lambda function (it was reviewed in batches because it has too many files for one pass together). Combine them into ONE single, coherent, comprehensive overview of the function as a whole: what it does end-to-end, its entry point, its overall data flow across the pieces described, and what external services it touches. Write only the combined overview itself — plain prose, no headers, no JSON, no preamble, no mention that it was assembled from parts."""


class ScanError(Exception):
    pass


def provider_available(provider: str) -> bool:
    """Whether the *library* needed for this provider is present — separate
    from whether an API key is configured, which is checked at call time."""
    if provider == "deepseek":
        return True  # just needs an API key; the HTTP call uses `requests`
    if provider == "anthropic":
        return anthropic is not None
    return False


def _require_key(provider: str, api_key: str):
    if provider not in PROVIDERS:
        raise ScanError("No AI provider selected. Choose one on the connect page.")
    if not api_key:
        env_var = "DEEPSEEK_API_KEY" if provider == "deepseek" else "ANTHROPIC_API_KEY"
        raise ScanError(
            f"No API key configured for {provider}. Add one on the connect page, "
            f"or set {env_var} in the environment this app runs in."
        )


def scan_code(provider: str, api_key: str, code: str, filename: str, function_name: str) -> dict:
    """Reviews one file."""
    _require_key(provider, api_key)

    trimmed = code
    if len(code) > MAX_CHARS:
        trimmed = code[:MAX_CHARS] + "\n\n# ... truncated for review, the file is larger than shown ..."
    user_content = f"File: {filename}\nFrom Lambda function: {function_name}\n\n```\n{trimmed}\n```"

    text = _call(provider, api_key, FILE_SYSTEM_PROMPT, user_content, max_tokens=2000)
    return _parse_response(text, overview_key="summary")


def _batch_files(files: list, max_chars: int) -> list:
    """
    Splits `files` (in the order the caller wants them prioritized) into
    batches, each within `max_chars` combined — never splitting one file's
    content across two batches. A single file bigger than the whole budget
    gets its own batch (still included, just truncated when sent).
    """
    batches, current, current_chars = [], [], 0
    for f in files:
        flen = len(f["content"])
        if current and current_chars + flen > max_chars:
            batches.append(current)
            current, current_chars = [], 0
        current.append(f)
        current_chars += flen
    if current:
        batches.append(current)
    return batches


def scan_function(provider: str, api_key: str, files: list, function_name: str) -> dict:
    """
    Reviews every file in `files` (a list of {"path", "content"}, already
    ordered by the caller — e.g. by import-graph discovery order, entry
    point first). Splits into as many batches as needed to cover all of
    them rather than capping at a fixed file count, runs the batches in
    parallel, and merges the results into one report. If the graph is
    larger than MAX_BATCHES worth of files, the excess is reported as
    skipped rather than silently dropped or run without limit.
    """
    _require_key(provider, api_key)

    if not files:
        raise ScanError("No Python files found to scan.")

    all_batches = _batch_files(files, MAX_BATCH_CHARS)
    batches = all_batches[:MAX_BATCHES]
    skipped_files = [f["path"] for b in all_batches[MAX_BATCHES:] for f in b]

    if len(batches) == 1:
        batch_results = [_scan_one_batch(provider, api_key, batches[0], function_name, 1, 1)]
    else:
        batch_results = [None] * len(batches)
        with ThreadPoolExecutor(max_workers=min(BATCH_CONCURRENCY, len(batches))) as pool:
            future_to_idx = {
                pool.submit(_scan_one_batch, provider, api_key, b, function_name, i + 1, len(batches)): i
                for i, b in enumerate(batches)
            }
            first_error = None
            for future in as_completed(future_to_idx):
                idx = future_to_idx[future]
                try:
                    batch_results[idx] = future.result()
                except ScanError as e:
                    if first_error is None:
                        first_error = e
                    batch_results[idx] = {"overview": "", "vulnerabilities": [], "notes": "", "_batch_files": [f["path"] for f in batches[idx]], "_batch_error": str(e)}
        if first_error is not None and all(r.get("_batch_error") for r in batch_results):
            # every single batch failed the same way (bad key, provider down, etc.) — surface that plainly
            raise first_error

    all_vulns, included_files, notes_parts, overviews, batch_errors = [], [], [], [], []
    for r in batch_results:
        all_vulns.extend(r.get("vulnerabilities", []))
        included_files.extend(r.get("_batch_files", []))
        if r.get("notes"):
            notes_parts.append(r["notes"])
        if r.get("_batch_error"):
            batch_errors.append(r["_batch_error"])
        else:
            overviews.append(r.get("overview", ""))

    if len(batches) == 1:
        overview = overviews[0] if overviews else ""
    else:
        overview = _synthesize_overview(provider, api_key, overviews, function_name)

    if batch_errors:
        notes_parts.append(
            f"{len(batch_errors)} of {len(batches)} batch(es) failed and were left out of this report: "
            + "; ".join(batch_errors[:3])
        )

    return {
        "overview": overview,
        "vulnerabilities": all_vulns,
        "notes": "\n".join(notes_parts),
        "included_files": included_files,
        "skipped_files": skipped_files,
        "batch_count": len(batches),
    }


def _scan_one_batch(provider: str, api_key: str, batch_files: list, function_name: str, batch_idx: int, batch_count: int) -> dict:
    parts = [f"Lambda function: {function_name}"]
    if batch_count > 1:
        parts.append(
            f"This is batch {batch_idx} of {batch_count} — the function has more files than fit in one "
            "review, so it's split across several. Review just the files below as thoroughly as you can; "
            "a separate pass combines every batch's findings afterward."
        )
    parts.append(f"{len(batch_files)} Python file(s) included below.")
    for f in batch_files:
        content = f["content"]
        if len(content) > MAX_SINGLE_FILE_CHARS_IN_BATCH:
            content = content[:MAX_SINGLE_FILE_CHARS_IN_BATCH] + "\n# ... truncated to fit this batch's budget ..."
        parts.append(f"\n=== File: {f['path']} ===\n{content}")
    user_content = "\n".join(parts)

    text = _call(provider, api_key, FUNCTION_SYSTEM_PROMPT, user_content, max_tokens=4000)
    result = _parse_response(text, overview_key="overview")
    result["_batch_files"] = [f["path"] for f in batch_files]
    return result


def _synthesize_overview(provider: str, api_key: str, overviews: list, function_name: str) -> str:
    """Combines several batches' partial overviews into one coherent
    narrative — a small extra call (partial overviews only, not the source
    again) so 'comprehensive overview of the entire function' holds up
    even when the function needed multiple batches to review."""
    joined = "\n\n".join(f"--- Partial overview {i + 1} ---\n{o}" for i, o in enumerate(overviews) if o)
    if not joined.strip():
        return ""
    user_content = f"Lambda function: {function_name}\n\n{joined}"
    try:
        return _call(provider, api_key, SYNTHESIS_SYSTEM_PROMPT, user_content, max_tokens=1500, json_mode=False).strip()
    except ScanError:
        # Synthesis failing shouldn't lose the underlying findings — fall
        # back to the partial overviews concatenated as-is.
        return joined


def _call(provider: str, api_key: str, system: str, user_content: str, max_tokens: int, json_mode: bool = True) -> str:
    if provider == "deepseek":
        return _call_deepseek(api_key, system, user_content, max_tokens, json_mode)
    return _call_anthropic(api_key, system, user_content, max_tokens)


def _call_deepseek(api_key: str, system: str, user_content: str, max_tokens: int, json_mode: bool = True) -> str:
    body = {
        "model": DEEPSEEK_MODEL,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": user_content},
        ],
        "max_tokens": max_tokens,
        "stream": False,
    }
    if json_mode:
        body["response_format"] = {"type": "json_object"}

    try:
        resp = requests.post(
            DEEPSEEK_API_URL,
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
            json=body,
            timeout=120,
        )
    except requests.exceptions.RequestException as e:
        raise ScanError(f"Couldn't reach the DeepSeek API: {e}")

    if resp.status_code == 401:
        raise ScanError("DeepSeek rejected that API key.")
    if resp.status_code != 200:
        raise ScanError(f"DeepSeek API error ({resp.status_code}): {_extract_http_error(resp)}")

    try:
        data = resp.json()
        return data["choices"][0]["message"]["content"]
    except (KeyError, IndexError, ValueError) as e:
        raise ScanError(f"Unexpected response from DeepSeek: {e}")


def _extract_http_error(resp) -> str:
    try:
        data = resp.json()
        return data.get("error", {}).get("message", resp.text[:200])
    except ValueError:
        return resp.text[:200]


def _call_anthropic(api_key: str, system: str, user_content: str, max_tokens: int) -> str:
    if anthropic is None:
        raise ScanError(
            "The 'anthropic' package isn't installed. Run: pip install anthropic — "
            "or switch the provider to DeepSeek on the connect page, which needs no extra package."
        )
    client = anthropic.Anthropic(api_key=api_key)
    try:
        resp = client.messages.create(
            model=ANTHROPIC_MODEL,
            max_tokens=max_tokens,
            system=system,
            messages=[{"role": "user", "content": user_content}],
        )
    except anthropic.AuthenticationError:
        raise ScanError("Anthropic rejected that API key.")
    except anthropic.APIStatusError as e:
        raise ScanError(f"Anthropic API error ({e.status_code}): {getattr(e, 'message', str(e))}")
    except Exception as e:
        raise ScanError(f"Couldn't reach the Anthropic API: {e}")

    return "".join(block.text for block in resp.content if getattr(block, "type", None) == "text")


def _parse_response(text: str, overview_key: str) -> dict:
    cleaned = text.strip()
    if cleaned.startswith("```"):
        cleaned = cleaned.strip("`")
        if cleaned.lower().startswith("json"):
            cleaned = cleaned[4:]
        cleaned = cleaned.strip()
    try:
        data = json.loads(cleaned)
    except json.JSONDecodeError:
        # The model didn't give us clean JSON — still show something useful
        # rather than a bare error.
        return {overview_key: text.strip(), "vulnerabilities": [], "notes": ""}

    data.setdefault(overview_key, "")
    data.setdefault("vulnerabilities", [])
    data.setdefault("notes", "")
    return data
