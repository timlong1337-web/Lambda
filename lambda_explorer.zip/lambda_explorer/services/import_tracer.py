"""
Statically traces a Python Lambda function's import graph, starting from
its handler, so a whole-function AI scan reviews the files the code
actually pulls in — rather than either every .py file in the package
(which can include megabytes of vendored dependencies) or an arbitrary
cap that silently drops files in a large, legitimately multi-file
function.

Pure static analysis via `ast` — nothing here imports or executes the
code being examined.
"""
import ast
import os
import re


def find_vendored_top_level_names(root: str) -> set:
    """
    Looks for '<name>-<version>.dist-info' / '.egg-info' entries at the
    package root — the trace pip leaves behind when a dependency is
    installed straight into a Lambda deployment package (a common way to
    vendor requirements) — and returns the top-level import names those
    correspond to, so the tracer treats them as external and doesn't walk
    into their internals.
    """
    names = set()
    try:
        entries = os.listdir(root)
    except OSError:
        return names
    for entry in entries:
        m = re.match(r"^(.+?)-[0-9][^-]*\.(dist-info|egg-info)$", entry)
        if m:
            pkg = m.group(1)
            names.add(pkg.lower())
            names.add(pkg.replace("-", "_").lower())
    return names


def extract_imports(source: str) -> list:
    """
    Returns [(module_dotted_name_or_None, level), ...] for every import
    statement in `source`. level is 0 for an absolute import, and the
    number of leading dots for a relative one (ast.ImportFrom.level).

    For `from package import submodule`, both 'package' and
    'package.submodule' are returned as candidates — Python's own grammar
    doesn't distinguish "importing a name" from "importing a submodule" at
    this syntax, and 'submodule' is very often actually a file
    (package/submodule.py) that's worth tracing into. Resolution simply
    won't find a match for the (far more common) case where it's really
    just a function or class name, so this costs nothing to try.
    """
    try:
        tree = ast.parse(source)
    except (SyntaxError, ValueError, RecursionError):
        return []
    found = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                found.append((alias.name, 0))
        elif isinstance(node, ast.ImportFrom):
            level = node.level or 0
            found.append((node.module, level))
            for alias in node.names:
                if alias.name == "*":
                    continue
                combined = f"{node.module}.{alias.name}" if node.module else alias.name
                found.append((combined, level))
    return found


def _resolve(module_name, level, importing_path, existing_files):
    """Approximates Python's import resolution against the package's own
    file layout — good enough for tracing, not a full spec implementation."""
    if level > 0:
        parts = importing_path.split("/")[:-1]  # importing file's own package dir
        up = level - 1
        if up:
            parts = parts[:-up] if len(parts) >= up else []
        if module_name:
            parts = parts + module_name.split(".")
    else:
        if not module_name:
            return None
        parts = module_name.split(".")

    if not parts:
        return None

    as_module = "/".join(parts) + ".py"
    as_package = "/".join(parts) + "/__init__.py"
    if as_module in existing_files:
        return as_module
    if as_package in existing_files:
        return as_package
    return None


def trace(root: str, entry_paths: list, all_py_paths: list, max_files: int = 150) -> list:
    """
    Breadth-first walk of the import graph starting from `entry_paths`,
    following only imports that (a) resolve to a real file in
    `all_py_paths` and (b) aren't a known vendored dependency. Returns
    paths in discovery order — entry points and their closest dependents
    first — which the caller uses to prioritize batching when the graph
    is too large for one AI request.

    Returns an empty list if none of the entry paths actually exist (the
    caller falls back to a flat file listing in that case).
    """
    existing = set(all_py_paths)
    vendored = find_vendored_top_level_names(root)

    visited, seen = [], set()
    queue = [p for p in entry_paths if p in existing]

    while queue and len(visited) < max_files:
        path = queue.pop(0)
        if path in seen:
            continue
        seen.add(path)
        visited.append(path)

        try:
            with open(os.path.join(root, path), "r", encoding="utf-8", errors="ignore") as fh:
                source = fh.read()
        except OSError:
            continue

        for module_name, level in extract_imports(source):
            top_level = (module_name or "").split(".")[0].lower()
            if level == 0 and top_level in vendored:
                continue
            resolved = _resolve(module_name, level, path, existing)
            if resolved and resolved not in seen:
                queue.append(resolved)

    return visited
