"""
Automatic C# decompilation for .NET Lambda packages.

Uses ilspycmd (the command-line front end for ILSpy — the standard, widely
used open-source .NET decompiler). It's not a Python package, so it has to
be installed separately on the host running this app:

    dotnet tool install -g ilspycmd

If it isn't installed, `is_available()` returns False and the app falls
back to offering the raw package for download with a clear explanation,
instead of failing.
"""
import os
import shutil
import subprocess
import tempfile

IGNORED_DLL_DIRS = {"runtimes"}  # native-asset folders, not managed assemblies


def is_available() -> bool:
    return shutil.which("ilspycmd") is not None


def find_assemblies(root: str) -> list:
    """Finds candidate managed .dll files to decompile, skipping native-asset dirs."""
    found = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in IGNORED_DLL_DIRS]
        for f in filenames:
            if f.lower().endswith(".dll"):
                found.append(os.path.join(dirpath, f))
    return sorted(found)


def decompile_assembly(dll_path: str, out_dir: str) -> tuple:
    """
    Decompiles one assembly into `out_dir`. Tries project mode first (one .cs
    file per type, closest to real source layout); falls back to a single
    combined .cs file if project mode isn't supported for that assembly.

    Returns (success: bool, message: str).
    """
    os.makedirs(out_dir, exist_ok=True)

    project_result = subprocess.run(
        ["ilspycmd", dll_path, "-p", "-o", out_dir],
        capture_output=True, text=True, timeout=180,
    )
    if project_result.returncode == 0:
        return True, "decompiled (project mode)"

    single_file = os.path.join(out_dir, os.path.basename(dll_path) + ".decompiled.cs")
    single_result = subprocess.run(
        ["ilspycmd", dll_path, "-o", single_file],
        capture_output=True, text=True, timeout=180,
    )
    if single_result.returncode == 0:
        return True, "decompiled (single file)"

    error = (single_result.stderr or project_result.stderr or "unknown ilspycmd error").strip()
    return False, error


def decompile_all(package_root: str) -> dict:
    """
    Finds and decompiles every managed assembly under package_root.
    Returns {"output_dir": str, "results": [{"dll": rel_path, "ok": bool, "message": str}]}
    """
    out_dir = tempfile.mkdtemp(prefix="decompiled_")
    results = []
    for dll_path in find_assemblies(package_root):
        rel = os.path.relpath(dll_path, package_root)
        target = os.path.join(out_dir, os.path.splitext(rel)[0])
        ok, message = decompile_assembly(dll_path, target)
        results.append({"dll": rel, "ok": ok, "message": message})
    return {"output_dir": out_dir, "results": results}
