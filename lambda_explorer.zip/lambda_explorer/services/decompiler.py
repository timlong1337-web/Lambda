"""
On-demand C# decompilation for .NET Lambda packages.

Uses ilspycmd (the command-line front end for ILSpy — the standard, widely
used open-source .NET decompiler). It's not a Python package, so it has to
be installed separately on the host running this app:

    dotnet tool install -g ilspycmd

If it isn't installed, `is_available()` returns False and the app falls
back to offering the raw package for download with a clear explanation,
instead of failing.

Decompilation happens one assembly at a time, triggered by the user
clicking a specific .dll in the viewer (see app.py's /decompile route) —
nothing here runs automatically for a whole package.

Successful decompiles are also cached to disk, content-addressed by a
hash of the assembly's own bytes (see content_hash/get_cached/cache_result
below) — so the same assembly is never decompiled twice, whether that's
because you reopened it after restarting the app, or because a totally
different function happens to bundle the identical dependency.
"""
import hashlib
import os
import shutil
import subprocess

_health_cache = {"checked": False, "healthy": None, "error": None}

# Where decompiled output is cached, content-addressed by the hash of the
# .dll's own bytes. Persists across restarts (unlike the in-memory cache
# in app.py, which is keyed by function+path and cleared on every
# restart) — override with an env var if you'd rather it live somewhere
# other than next to the app, e.g. a mounted volume in a container.
CACHE_DIR = os.environ.get(
    "DECOMPILE_CACHE_DIR",
    os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), ".decompile_cache"),
)
_CACHE_COMPLETE_MARKER = ".complete"


def is_available() -> bool:
    return shutil.which("ilspycmd") is not None


def check_runtime_health(force: bool = False) -> tuple:
    """
    Runs a trivial ilspycmd invocation to confirm the .NET runtime can even
    start on this machine. Memoized process-wide after the first call (success
    or failure) so repeated clicks on different DLLs don't each re-probe a
    runtime that's already known to be broken — they get the same clear
    answer instantly instead.

    Returns (healthy: bool, error: str | None).
    """
    if not force and _health_cache["checked"]:
        return _health_cache["healthy"], _health_cache["error"]

    try:
        result = subprocess.run(
            ["ilspycmd", "--version"], capture_output=True, text=True, timeout=30,
        )
        if result.returncode != 0:
            error = (result.stderr or result.stdout or "unknown error").strip()
            healthy = False
        else:
            error = None
            healthy = True
    except subprocess.TimeoutExpired:
        healthy, error = False, "ilspycmd --version timed out after 30s."
    except OSError as e:
        healthy, error = False, str(e)

    _health_cache.update(checked=True, healthy=healthy, error=error)
    return healthy, error


def decompile_assembly(dll_path: str, out_dir: str) -> tuple:
    """
    Decompiles one assembly into `out_dir`. Tries project mode first (one .cs
    file per type, closest to real source layout); falls back to a single
    combined .cs file if project mode isn't supported for that assembly.

    Returns (success: bool, message: str).
    """
    os.makedirs(out_dir, exist_ok=True)

    project_result = subprocess.run(
        ["ilspycmd", dll_path, "-p", "-o", out_dir],
        capture_output=True, text=True, timeout=180,
    )
    if project_result.returncode == 0:
        return True, "decompiled (project mode)"

    single_file = os.path.join(out_dir, os.path.basename(dll_path) + ".decompiled.cs")
    single_result = subprocess.run(
        ["ilspycmd", dll_path, "-o", single_file],
        capture_output=True, text=True, timeout=180,
    )
    if single_result.returncode == 0:
        return True, "decompiled (single file)"

    error = (single_result.stderr or project_result.stderr or "unknown ilspycmd error").strip()
    return False, error


# --------------------------------------------------------------------------
# Persistent, content-addressed decompile cache
# --------------------------------------------------------------------------

def content_hash(file_path: str) -> str:
    """SHA-256 of a file's bytes — the cache key. Content-addressed rather
    than keyed by function/path means the exact same assembly only ever
    gets decompiled once, no matter how many functions bundle it or how
    many times the app gets restarted in between."""
    h = hashlib.sha256()
    with open(file_path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _cache_dir_for(digest: str) -> str:
    # Two-level fan-out (like Git's object store) so the cache directory
    # doesn't end up with thousands of entries directly under one folder.
    return os.path.join(CACHE_DIR, digest[:2], digest)


def get_cached(digest: str):
    """Returns the cached output directory for this content hash, or None
    if nothing's cached for it (yet, or ever — a decompile that failed is
    never written here, only successes, so a miss doesn't imply anything
    about whether it's decompilable)."""
    if not digest:
        return None
    d = _cache_dir_for(digest)
    if os.path.isdir(d) and os.path.isfile(os.path.join(d, _CACHE_COMPLETE_MARKER)):
        return d
    return None


def cache_result(digest: str, source_dir: str) -> None:
    """
    Copies a successful decompile's output into the persistent cache.
    Best-effort: if this fails for any reason (permissions, disk space),
    the in-progress request is unaffected either way — it just means this
    assembly gets decompiled fresh again next time instead of served from
    cache. The completion marker is written last, after the copy fully
    succeeds, so a crash or interruption mid-write can never leave behind
    a corrupt entry that looks valid.
    """
    if not digest:
        return
    dest = _cache_dir_for(digest)
    try:
        if os.path.isdir(dest):
            shutil.rmtree(dest, ignore_errors=True)
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        shutil.copytree(source_dir, dest)
        open(os.path.join(dest, _CACHE_COMPLETE_MARKER), "w").close()
    except OSError:
        pass


def cache_stats() -> dict:
    """A quick summary for anyone curious how much has accumulated —
    number of cached assemblies and total bytes on disk."""
    count, total_bytes = 0, 0
    if not os.path.isdir(CACHE_DIR):
        return {"entries": 0, "bytes": 0, "path": CACHE_DIR}
    for root, dirs, files in os.walk(CACHE_DIR):
        if _CACHE_COMPLETE_MARKER in files:
            count += 1
        for f in files:
            try:
                total_bytes += os.path.getsize(os.path.join(root, f))
            except OSError:
                pass
    return {"entries": count, "bytes": total_bytes, "path": CACHE_DIR}

