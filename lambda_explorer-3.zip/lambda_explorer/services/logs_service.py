"""
Fetches the most recent CloudWatch Logs events for a Lambda function, from
the log group AWS creates automatically for every function:

    /aws/lambda/<function-name>

Reads only the function's most recently active log streams rather than
scanning the whole group, so this stays fast even for functions with a
long history.
"""
from botocore.exceptions import ClientError


class LogsServiceError(Exception):
    pass


class LogsService:
    def __init__(self, session):
        self.client = session.client("logs")

    @staticmethod
    def log_group_name(function_name: str) -> str:
        return f"/aws/lambda/{function_name}"

    def fetch_latest(self, function_name: str, max_events: int = 200, max_streams: int = 5) -> list:
        """
        Returns up to `max_events` of the most recent log events across the
        function's `max_streams` most recently active log streams, oldest
        first. Each event: {"timestamp": <epoch ms>, "message": str}.
        """
        group = self.log_group_name(function_name)
        try:
            streams_resp = self.client.describe_log_streams(
                logGroupName=group,
                orderBy="LastEventTime",
                descending=True,
                limit=max_streams,
            )
        except ClientError as e:
            code = e.response.get("Error", {}).get("Code", "")
            if code == "ResourceNotFoundException":
                raise LogsServiceError(
                    "No log group found for this function yet — it may not have been invoked."
                )
            raise LogsServiceError(self._friendly(e))

        streams = streams_resp.get("logStreams", [])
        if not streams:
            return []

        events = []
        for stream in streams:
            stream_name = stream.get("logStreamName")
            if not stream_name:
                continue
            try:
                resp = self.client.get_log_events(
                    logGroupName=group,
                    logStreamName=stream_name,
                    limit=max_events,
                    startFromHead=False,
                )
            except ClientError:
                continue  # one bad stream shouldn't sink the whole request
            for ev in resp.get("events", []):
                events.append({"timestamp": ev["timestamp"], "message": ev["message"]})

        events.sort(key=lambda e: e["timestamp"])
        return events[-max_events:]

    @staticmethod
    def _friendly(e: ClientError) -> str:
        code = e.response.get("Error", {}).get("Code", "Unknown")
        message = e.response.get("Error", {}).get("Message", str(e))
        return f"{code}: {message}"
