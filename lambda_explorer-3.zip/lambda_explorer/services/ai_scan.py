"""
Optional AI-assisted review for whichever file is open in the source
viewer: a plain-English summary of what it does, plus a best-effort
security pass. Uses the Anthropic API directly with a user-supplied key —
this is a fast first read, not a substitute for a real audit.
"""
import json
import os

try:
    import anthropic
except ImportError:  # the app still runs without this installed; see is_available()
    anthropic = None

DEFAULT_MODEL = os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-5")
MAX_CHARS = 60_000  # keep a single review to a sane token budget

SYSTEM_PROMPT = """You are a careful application security reviewer looking at one file from an AWS Lambda function's deployment package (it may be original source or decompiled — decompiled code can have generic names and lost comments; review the logic itself).

Respond with ONLY a JSON object, no markdown fences, no prose outside the JSON, in exactly this shape:
{
  "summary": "2-4 sentence plain-English explanation of what this file does",
  "vulnerabilities": [
    {"title": "short name", "severity": "low|medium|high|critical", "description": "what the issue is, and where in the file", "recommendation": "how to fix it"}
  ],
  "notes": "anything else worth flagging that isn't a security issue, or empty string"
}

If you find no plausible vulnerabilities, return an empty vulnerabilities array — don't invent issues just to have something to report. Be specific and reference the actual code rather than giving generic advice."""


class ScanError(Exception):
    pass


def is_available() -> bool:
    return anthropic is not None


def scan_code(api_key: str, code: str, filename: str, function_name: str) -> dict:
    if anthropic is None:
        raise ScanError("The 'anthropic' package isn't installed. Run: pip install anthropic")
    if not api_key:
        raise ScanError(
            "No Anthropic API key configured. Add one on the connect page, "
            "or set ANTHROPIC_API_KEY in the environment this app runs in."
        )

    trimmed = code
    if len(code) > MAX_CHARS:
        trimmed = code[:MAX_CHARS] + "\n\n# ... truncated for review, the file is larger than shown ..."

    user_content = f"File: {filename}\nFrom Lambda function: {function_name}\n\n```\n{trimmed}\n```"

    client = anthropic.Anthropic(api_key=api_key)
    try:
        resp = client.messages.create(
            model=DEFAULT_MODEL,
            max_tokens=2000,
            system=SYSTEM_PROMPT,
            messages=[{"role": "user", "content": user_content}],
        )
    except anthropic.AuthenticationError:
        raise ScanError("Anthropic rejected that API key.")
    except anthropic.APIStatusError as e:
        raise ScanError(f"Anthropic API error ({e.status_code}): {getattr(e, 'message', str(e))}")
    except Exception as e:
        raise ScanError(f"Couldn't reach the Anthropic API: {e}")

    text = "".join(block.text for block in resp.content if getattr(block, "type", None) == "text")
    return _parse_response(text)


def _parse_response(text: str) -> dict:
    cleaned = text.strip()
    if cleaned.startswith("```"):
        cleaned = cleaned.strip("`")
        if cleaned.lower().startswith("json"):
            cleaned = cleaned[4:]
        cleaned = cleaned.strip()
    try:
        data = json.loads(cleaned)
    except json.JSONDecodeError:
        # The model didn't give us clean JSON — still show something useful
        # rather than a bare error.
        return {"summary": text.strip(), "vulnerabilities": [], "notes": ""}

    data.setdefault("summary", "")
    data.setdefault("vulnerabilities", [])
    data.setdefault("notes", "")
    return data
