"""
AWS Role & Lambda Privilege-Escalation Scanner
------------------------------------------------
A local Flask dashboard for auditing IAM roles and Lambda functions in your
own AWS account. It surfaces two known privilege-escalation patterns:

  1. Roles that trust lambda.amazonaws.com, where the current caller also
     has iam:PassRole + lambda:CreateFunction on that role -- meaning you
     could create a brand new Lambda function that runs as that role.
  2. Roles that an existing Lambda function's execution role is permitted
     to sts:AssumeRole into -- i.e. what code running inside that function
     could pivot to.

It also statically scans deployed Python Lambda source code for usage of
boto3 iam/sts clients and assume_role() calls, so you can see which
functions are actually exercising those permissions in code.

This tool is READ-ONLY against AWS: it never creates, deletes, or modifies
any resource, and never stores or transmits your credentials -- it relies
entirely on boto3's standard credential chain (env vars, ~/.aws/credentials,
an instance profile, SSO, etc).

Setup:
    pip install -r requirements.txt
    export AWS_PROFILE=your-profile      # or set AWS_* env vars / use SSO
    python app.py
Then open http://127.0.0.1:5000

Required permissions (read-only): iam:ListRoles, iam:GetRole,
iam:SimulatePrincipalPolicy, lambda:ListFunctions, lambda:GetFunction,
sts:GetCallerIdentity. See README.md for details and limitations.
"""
import os

import boto3
import botocore
from flask import Flask, jsonify, render_template, request

from scanner.aws_enum import get_caller_identity, list_lambda_functions, list_roles
from scanner.code_scanner import scan_all_functions
from scanner.priv_esc import analyze_assume_role_escalation, analyze_create_function_escalation

app = Flask(__name__)

AWS_REGION = os.environ.get("AWS_REGION", os.environ.get("AWS_DEFAULT_REGION", "us-east-1"))
AWS_PROFILE = os.environ.get("AWS_PROFILE")


def get_session():
    if AWS_PROFILE:
        return boto3.Session(profile_name=AWS_PROFILE, region_name=AWS_REGION)
    return boto3.Session(region_name=AWS_REGION)


@app.route("/")
def index():
    return render_template("index.html", region=AWS_REGION, profile=AWS_PROFILE or "(default)")


@app.route("/api/identity")
def api_identity():
    try:
        session = get_session()
        sts = session.client("sts")
        identity = get_caller_identity(sts)
        return jsonify({"ok": True, "identity": identity})
    except botocore.exceptions.NoCredentialsError:
        return jsonify({"ok": False, "error": "No AWS credentials found. Set AWS_PROFILE or AWS_* env vars."}), 400
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500


@app.route("/api/roles")
def api_roles():
    try:
        session = get_session()
        iam = session.client("iam")
        roles = list_roles(iam)
        return jsonify({"ok": True, "count": len(roles), "roles": roles})
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500


@app.route("/api/lambdas")
def api_lambdas():
    try:
        session = get_session()
        lam = session.client("lambda")
        functions = list_lambda_functions(lam)
        return jsonify({"ok": True, "count": len(functions), "functions": functions})
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500


@app.route("/api/analysis")
def api_analysis():
    """Privilege-escalation style analysis. Read-only; uses IAM's own policy
    simulator so results reflect what AWS would actually evaluate (note:
    the simulator does not account for SCPs or permission boundaries)."""
    try:
        max_roles = int(request.args.get("max_roles", 75))
        session = get_session()
        iam = session.client("iam")
        lam = session.client("lambda")
        sts = session.client("sts")

        identity = get_caller_identity(sts)
        roles = list_roles(iam)[:max_roles]
        functions = list_lambda_functions(lam)

        create_fn_paths = analyze_create_function_escalation(iam, roles, identity["Arn"])
        assume_paths = analyze_assume_role_escalation(iam, roles, functions)

        return jsonify({
            "ok": True,
            "caller": identity,
            "roles_analyzed": len(roles),
            "create_function_paths": create_fn_paths,
            "assume_role_paths": assume_paths,
        })
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500


@app.route("/api/scan-code")
def api_scan_code():
    try:
        session = get_session()
        lam = session.client("lambda")
        functions = list_lambda_functions(lam)
        max_size_mb = float(request.args.get("max_size_mb", 50))
        results = scan_all_functions(lam, functions, max_size_mb=max_size_mb)
        return jsonify({"ok": True, "results": results})
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500


if __name__ == "__main__":
    app.run(debug=True, port=5000)
