"""Read-only AWS enumeration helpers. No mutating API calls are made here."""
import json
from urllib.parse import unquote


def get_caller_identity(sts_client):
    resp = sts_client.get_caller_identity()
    return {"Account": resp["Account"], "Arn": resp["Arn"], "UserId": resp["UserId"]}


def _normalize_policy_doc(doc):
    """boto3 normally auto-decodes IAM policy documents into dicts, but be
    defensive in case a raw URL-encoded JSON string comes through."""
    if isinstance(doc, str):
        try:
            return json.loads(unquote(doc))
        except (ValueError, TypeError):
            return {}
    return doc or {}


def _trusts_service(trust_doc, service):
    statements = trust_doc.get("Statement", [])
    if isinstance(statements, dict):
        statements = [statements]
    for stmt in statements:
        if stmt.get("Effect") != "Allow":
            continue
        principal = stmt.get("Principal", {})
        services = principal.get("Service", []) if isinstance(principal, dict) else []
        if isinstance(services, str):
            services = [services]
        if service in services:
            return True
    return False


def list_roles(iam_client):
    """Return all IAM roles with their trust policy and whether they trust
    the Lambda service (i.e. could be attached to a new Lambda function)."""
    roles = []
    paginator = iam_client.get_paginator("list_roles")
    for page in paginator.paginate():
        for role in page["Roles"]:
            trust_doc = _normalize_policy_doc(role.get("AssumeRolePolicyDocument"))
            roles.append({
                "RoleName": role["RoleName"],
                "Arn": role["Arn"],
                "Path": role.get("Path", "/"),
                "CreateDate": str(role.get("CreateDate", "")),
                "TrustPolicy": trust_doc,
                "TrustsLambda": _trusts_service(trust_doc, "lambda.amazonaws.com"),
            })
    return roles


def list_lambda_functions(lambda_client):
    """Return all Lambda functions with their execution role ARN."""
    functions = []
    paginator = lambda_client.get_paginator("list_functions")
    for page in paginator.paginate():
        for fn in page["Functions"]:
            functions.append({
                "FunctionName": fn["FunctionName"],
                "FunctionArn": fn["FunctionArn"],
                "Role": fn.get("Role"),
                "Runtime": fn.get("Runtime", ""),
                "PackageType": fn.get("PackageType", "Zip"),
                "CodeSize": fn.get("CodeSize", 0),
                "LastModified": fn.get("LastModified", ""),
            })
    return functions
