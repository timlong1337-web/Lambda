"""
Privilege-escalation style analysis.

Both checks below call IAM's own policy simulator (iam:SimulatePrincipalPolicy)
rather than a hand-rolled policy-document parser, so results reflect what AWS
itself would evaluate. Caveats: the simulator does NOT account for Service
Control Policies (SCPs), permission boundaries, or resource-based policies
outside IAM, so an "allowed" result here is necessary but not always
sufficient for a real escalation -- verify anything interesting by hand
before treating it as a confirmed finding.

Requires iam:SimulatePrincipalPolicy on the credentials running this tool.
If that permission is missing, checks are skipped gracefully (reported as
`None` / "unknown") rather than crashing the scan.
"""


def _simulate(iam_client, principal_arn, actions, resource_arn):
    """Return True/False, or None if the result could not be determined
    (e.g. no permission to call the simulator)."""
    try:
        resp = iam_client.simulate_principal_policy(
            PolicySourceArn=principal_arn,
            ActionNames=actions,
            ResourceArns=[resource_arn],
        )
    except Exception:
        return None

    results = {r["EvalActionName"]: r["EvalDecision"] for r in resp.get("EvaluationResults", [])}
    if not results:
        return None
    return all(v == "allowed" for v in results.values())


def analyze_create_function_escalation(iam_client, roles, caller_arn):
    """
    For each role that trusts the Lambda service, check whether the current
    caller could PassRole it into a brand-new Lambda function
    (iam:PassRole + lambda:CreateFunction) -- since code in that new
    function would then run with the role's permissions.
    """
    findings = []
    for role in roles:
        if not role["TrustsLambda"]:
            continue
        allowed = _simulate(
            iam_client,
            caller_arn,
            ["iam:PassRole", "lambda:CreateFunction"],
            role["Arn"],
        )
        findings.append({
            "RoleName": role["RoleName"],
            "RoleArn": role["Arn"],
            "CallerCanPassRoleAndCreateFunction": allowed,
        })
    return findings


def analyze_assume_role_escalation(iam_client, roles, functions):
    """
    For each distinct Lambda execution role, check which other roles it is
    permitted to sts:AssumeRole into -- i.e. what a compromised or malicious
    function running as that execution role could pivot to.

    Note: this is O(execution_roles x roles) simulate_principal_policy calls,
    so it can be slow on accounts with many roles. Use max_roles on the
    /api/analysis endpoint to cap it.
    """
    findings = []
    exec_roles = sorted({fn["Role"] for fn in functions if fn.get("Role")})

    for exec_role_arn in exec_roles:
        assumable = []
        for target in roles:
            if target["Arn"] == exec_role_arn:
                continue
            allowed = _simulate(iam_client, exec_role_arn, ["sts:AssumeRole"], target["Arn"])
            if allowed:
                assumable.append({"RoleName": target["RoleName"], "RoleArn": target["Arn"]})
        related_functions = [fn["FunctionName"] for fn in functions if fn.get("Role") == exec_role_arn]
        findings.append({
            "ExecutionRoleArn": exec_role_arn,
            "Functions": related_functions,
            "AssumableRoles": assumable,
        })
    return findings
