"""
Static scanner for Lambda deployment packages: flags Python source that uses
boto3 IAM/STS clients or calls assume_role(), so you can see which functions
are actually exercising IAM/STS related permissions in their code (as
opposed to merely holding related IAM permissions on paper).

This is a lightweight AST-based scan, not full data-flow analysis: it will
have false positives (e.g. a variable that happens to be named "iam" isn't
flagged, but an aliased client can be missed) and false negatives (heavily
dynamic code, wrapper libraries, etc). Treat it as a triage aid, not ground
truth -- always read the flagged lines yourself.
"""
import ast
import io
import os
import shutil
import tempfile
import zipfile

import requests

WATCHED_SERVICES = {"iam", "sts"}
WATCHED_METHODS = {"assume_role", "assume_role_with_web_identity", "assume_role_with_saml"}


class IamStsVisitor(ast.NodeVisitor):
    def __init__(self, source_lines):
        self.source_lines = source_lines
        self.findings = []

    def _snippet(self, lineno):
        idx = lineno - 1
        return self.source_lines[idx].strip() if 0 <= idx < len(self.source_lines) else ""

    def visit_Call(self, node):
        func = node.func
        # boto3.client("iam") / boto3.resource("sts")
        if isinstance(func, ast.Attribute) and func.attr in {"client", "resource"}:
            first_arg = node.args[0] if node.args else None
            service = None
            if isinstance(first_arg, ast.Constant) and isinstance(first_arg.value, str):
                service = first_arg.value.lower()
            if service in WATCHED_SERVICES:
                self.findings.append({
                    "type": f"boto3.{func.attr}('{service}')",
                    "line": node.lineno,
                    "snippet": self._snippet(node.lineno),
                })
        # anything.assume_role(...)
        if isinstance(func, ast.Attribute) and func.attr in WATCHED_METHODS:
            self.findings.append({
                "type": f"call to .{func.attr}()",
                "line": node.lineno,
                "snippet": self._snippet(node.lineno),
            })
        self.generic_visit(node)


def _scan_python_source(path):
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            source = f.read()
        tree = ast.parse(source, filename=path)
    except (SyntaxError, ValueError):
        return []
    visitor = IamStsVisitor(source.splitlines())
    visitor.visit(tree)
    return visitor.findings


def scan_function_code(lambda_client, function_name, package_type, max_size_mb=50):
    if package_type == "Image":
        return {"status": "skipped", "reason": "Container image function; source not directly inspectable."}

    detail = lambda_client.get_function(FunctionName=function_name)
    location = detail.get("Code", {}).get("Location")
    code_size = detail.get("Configuration", {}).get("CodeSize", 0)
    if not location:
        return {"status": "skipped", "reason": "No downloadable code location returned."}
    if code_size > max_size_mb * 1024 * 1024:
        return {"status": "skipped", "reason": f"Package larger than {max_size_mb}MB limit."}

    tmp_dir = tempfile.mkdtemp(prefix="lambda_scan_")
    try:
        resp = requests.get(location, timeout=30)
        resp.raise_for_status()
        with zipfile.ZipFile(io.BytesIO(resp.content)) as zf:
            zf.extractall(tmp_dir)

        all_findings = []
        for root, _dirs, files in os.walk(tmp_dir):
            for fname in files:
                if fname.endswith(".py"):
                    fpath = os.path.join(root, fname)
                    rel = os.path.relpath(fpath, tmp_dir)
                    for finding in _scan_python_source(fpath):
                        finding["file"] = rel
                        all_findings.append(finding)
        return {"status": "scanned", "findings": all_findings}
    except Exception as exc:
        return {"status": "error", "reason": str(exc)}
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)


def scan_all_functions(lambda_client, functions, max_size_mb=50):
    results = []
    for fn in functions:
        outcome = scan_function_code(
            lambda_client, fn["FunctionName"], fn.get("PackageType", "Zip"), max_size_mb=max_size_mb
        )
        results.append({
            "FunctionName": fn["FunctionName"],
            "Role": fn.get("Role"),
            **outcome,
        })
    return results
