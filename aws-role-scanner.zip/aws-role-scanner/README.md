# AWS Role & Lambda Privilege-Escalation Scanner

A local Flask dashboard for auditing your own AWS account. It's **read-only**
against AWS — it never creates, deletes, or modifies any resource, and never
stores or transmits your credentials. It uses boto3's normal credential chain
(env vars, `~/.aws/credentials`, an instance profile, SSO, etc), so nothing
ever gets typed into the app itself.

## What it does

1. **Enumerate** — lists all IAM roles (with trust policy) and all Lambda
   functions (with execution role).
2. **Privilege-escalation analysis**, using AWS's own `iam:SimulatePrincipalPolicy`
   API rather than a hand-rolled policy parser:
   - Which roles trust `lambda.amazonaws.com`, and does the *current caller*
     also have `iam:PassRole` + `lambda:CreateFunction` on that role? If so,
     you could create a brand-new Lambda function that runs as that role.
   - For each existing Lambda function's execution role, which other roles
     can it `sts:AssumeRole` into? That's what code running inside the
     function could pivot to.
3. **Source code scan** — downloads each function's deployment package and
   walks the Python AST for `boto3.client("iam"/"sts")`,
   `boto3.resource("iam"/"sts")`, and `.assume_role()` / `.assume_role_with_*()`
   calls, reporting file, line number, and a snippet.

## Setup

```bash
pip install -r requirements.txt
export AWS_PROFILE=your-profile     # or set AWS_* env vars / use SSO login
export AWS_REGION=us-east-1         # optional, defaults to us-east-1
python app.py
```

Open http://127.0.0.1:5000

## Required IAM permissions (all read-only)

```
iam:ListRoles
iam:SimulatePrincipalPolicy
lambda:ListFunctions
lambda:GetFunction
sts:GetCallerIdentity
```

If `iam:SimulatePrincipalPolicy` isn't granted, the analysis step degrades
gracefully — affected checks show `unknown` instead of failing the whole scan.

## Limitations / things to know

- **The policy simulator doesn't see everything.** `simulate_principal_policy`
  evaluates identity-based policies only — it does **not** account for
  Service Control Policies (SCPs), permission boundaries, or session
  policies. Treat "YES" results as leads to verify, not confirmed exploits.
- **The assume-role check is O(execution roles × total roles)** in API calls.
  On accounts with hundreds of roles this can be slow / throttled; use the
  `max_roles` query param on `/api/analysis` (default 75) to cap it.
- **The code scanner is a triage aid, not ground truth.** It's a static AST
  scan, not data-flow analysis: it can miss dynamically-constructed service
  names, wrapper libraries, or heavily obfuscated code, and it can't inspect
  container-image (`PackageType: Image`) functions at all.
- **Downloading deployment packages requires network egress** from wherever
  you run this app, since Lambda returns a presigned S3 URL for the code.
- Run this only against accounts you're authorized to audit.
