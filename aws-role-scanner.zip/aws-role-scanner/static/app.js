function el(tag, attrs, children) {
  const node = document.createElement(tag);
  Object.entries(attrs || {}).forEach(([k, v]) => {
    if (k === "text") node.textContent = v;
    else if (k === "html") node.innerHTML = v;
    else node.setAttribute(k, v);
  });
  (children || []).forEach((c) => node.appendChild(c));
  return node;
}

function badge(value) {
  if (value === true) return `<span class="badge badge-yes">YES</span>`;
  if (value === false) return `<span class="badge badge-no">no</span>`;
  return `<span class="badge badge-unknown">unknown</span>`;
}

function renderTable(container, columns, rows, emptyMsg) {
  container.innerHTML = "";
  if (!rows || rows.length === 0) {
    container.appendChild(el("div", { class: "empty", text: emptyMsg || "No results." }));
    return;
  }
  const table = el("table");
  const thead = el("thead");
  const headRow = el("tr");
  columns.forEach((c) => headRow.appendChild(el("th", { text: c.label })));
  thead.appendChild(headRow);
  table.appendChild(thead);

  const tbody = el("tbody");
  rows.forEach((row) => {
    const tr = el("tr");
    columns.forEach((c) => {
      const td = el("td");
      const val = c.render ? c.render(row) : (row[c.key] ?? "");
      if (c.html) td.innerHTML = val;
      else td.textContent = val;
      tr.appendChild(td);
    });
    tbody.appendChild(tr);
  });
  table.appendChild(tbody);
  container.appendChild(table);
}

async function callApi(url) {
  const resp = await fetch(url);
  const data = await resp.json();
  if (!data.ok) throw new Error(data.error || "Request failed");
  return data;
}

function withLoading(button, fn) {
  return async () => {
    button.disabled = true;
    const original = button.textContent;
    button.textContent = "Working…";
    try {
      await fn();
    } catch (err) {
      alert(err.message);
    } finally {
      button.disabled = false;
      button.textContent = original;
    }
  };
}

// --- Identity ---
async function loadIdentity() {
  const box = document.getElementById("identity");
  try {
    const data = await callApi("/api/identity");
    box.textContent = `Authenticated as ${data.identity.Arn}`;
  } catch (err) {
    box.textContent = `Not authenticated: ${err.message}`;
  }
}

// --- Roles ---
document.getElementById("btn-roles").addEventListener("click", withLoading(document.getElementById("btn-roles"), async () => {
  const data = await callApi("/api/roles");
  document.getElementById("roles-count").textContent = `(${data.count})`;
  renderTable(document.getElementById("roles-table"), [
    { label: "Role Name", key: "RoleName" },
    { label: "Trusts Lambda?", html: true, render: (r) => badge(r.TrustsLambda) },
    { label: "ARN", key: "Arn" },
  ], data.roles, "No IAM roles found.");
}));

// --- Lambda functions ---
document.getElementById("btn-lambdas").addEventListener("click", withLoading(document.getElementById("btn-lambdas"), async () => {
  const data = await callApi("/api/lambdas");
  document.getElementById("lambdas-count").textContent = `(${data.count})`;
  renderTable(document.getElementById("lambdas-table"), [
    { label: "Function", key: "FunctionName" },
    { label: "Runtime", key: "Runtime" },
    { label: "Execution Role", key: "Role" },
  ], data.functions, "No Lambda functions found.");
}));

// --- Privilege escalation analysis ---
document.getElementById("btn-analysis").addEventListener("click", withLoading(document.getElementById("btn-analysis"), async () => {
  const data = await callApi("/api/analysis");

  renderTable(document.getElementById("create-fn-table"), [
    { label: "Role", key: "RoleName" },
    { label: "You can PassRole + CreateFunction?", html: true, render: (r) => badge(r.CallerCanPassRoleAndCreateFunction) },
    { label: "Role ARN", key: "RoleArn" },
  ], data.create_function_paths, "No roles trust the Lambda service.");

  const assumeRows = [];
  data.assume_role_paths.forEach((p) => {
    if (p.AssumableRoles.length === 0) {
      assumeRows.push({
        ExecutionRoleArn: p.ExecutionRoleArn,
        Functions: p.Functions.join(", "),
        Target: "(none found)",
      });
    } else {
      p.AssumableRoles.forEach((t) => {
        assumeRows.push({
          ExecutionRoleArn: p.ExecutionRoleArn,
          Functions: p.Functions.join(", "),
          Target: t.RoleName,
        });
      });
    }
  });
  renderTable(document.getElementById("assume-table"), [
    { label: "Lambda Execution Role", key: "ExecutionRoleArn" },
    { label: "Function(s)", key: "Functions" },
    { label: "Can Assume Into", key: "Target" },
  ], assumeRows, "No Lambda execution roles found.");
}));

// --- Code scan ---
document.getElementById("btn-scan").addEventListener("click", withLoading(document.getElementById("btn-scan"), async () => {
  const data = await callApi("/api/scan-code");
  const rows = [];
  data.results.forEach((r) => {
    if (r.status === "scanned" && r.findings.length > 0) {
      r.findings.forEach((f) => {
        rows.push({
          FunctionName: r.FunctionName,
          File: f.file,
          Line: f.line,
          Type: f.type,
          Snippet: f.snippet,
        });
      });
    } else if (r.status === "scanned") {
      rows.push({ FunctionName: r.FunctionName, File: "-", Line: "-", Type: "no iam/sts usage found", Snippet: "" });
    } else {
      rows.push({ FunctionName: r.FunctionName, File: "-", Line: "-", Type: r.status, Snippet: r.reason || "" });
    }
  });
  renderTable(document.getElementById("scan-table"), [
    { label: "Function", key: "FunctionName" },
    { label: "File", key: "File" },
    { label: "Line", key: "Line" },
    { label: "Finding", key: "Type" },
    { label: "Snippet", html: true, render: (r) => `<span class="snippet">${r.Snippet ? r.Snippet.replace(/</g, "&lt;") : ""}</span>` },
  ], rows, "No Lambda functions to scan.");
}));

loadIdentity();
