"""
Talks to the AWS Lambda control plane: listing functions and fetching
the metadata + presigned download URL for a single function's deployment
package.
"""
import requests
from botocore.exceptions import ClientError


class LambdaServiceError(Exception):
    pass


class LambdaService:
    def __init__(self, session):
        self.client = session.client("lambda")

    def list_functions(self) -> list:
        """Returns every Lambda function in the account/region, across pages."""
        functions = []
        try:
            paginator = self.client.get_paginator("list_functions")
            for page in paginator.paginate():
                functions.extend(page.get("Functions", []))
        except ClientError as e:
            raise LambdaServiceError(self._friendly(e))
        functions.sort(key=lambda f: f.get("FunctionName", "").lower())
        return functions

    def get_function(self, name: str) -> dict:
        """Full GetFunction response: Configuration + Code (incl. presigned URL)."""
        try:
            return self.client.get_function(FunctionName=name)
        except ClientError as e:
            raise LambdaServiceError(self._friendly(e))

    def update_function_code(self, name: str, zip_bytes: bytes) -> dict:
        """
        Overwrites the deployed code for `name` with `zip_bytes` — this is
        the actual live-deploy call. Everything upstream of here (edit,
        build, diff, confirm) is about making sure this only ever runs
        when the person deploying really means it.
        """
        try:
            return self.client.update_function_code(FunctionName=name, ZipFile=zip_bytes)
        except ClientError as e:
            raise LambdaServiceError(self._friendly(e))

    def create_function(self, name: str, runtime: str, role_arn: str, handler: str, zip_bytes: bytes) -> dict:
        """Creates a brand-new function and publishes version 1 immediately."""
        try:
            return self.client.create_function(
                FunctionName=name,
                Runtime=runtime,
                Role=role_arn,
                Handler=handler,
                Code={"ZipFile": zip_bytes},
                Publish=True,
            )
        except ClientError as e:
            raise LambdaServiceError(self._friendly(e))

    @staticmethod
    def download_package(url: str) -> bytes:
        resp = requests.get(url, timeout=60)
        resp.raise_for_status()
        return resp.content

    @staticmethod
    def _friendly(e: ClientError) -> str:
        code = e.response.get("Error", {}).get("Code", "Unknown")
        message = e.response.get("Error", {}).get("Message", str(e))
        return f"{code}: {message}"
