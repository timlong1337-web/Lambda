"""
On-demand C# decompilation for .NET Lambda packages.

Uses ilspycmd (the command-line front end for ILSpy — the standard, widely
used open-source .NET decompiler). It's not a Python package, so it has to
be installed separately on the host running this app:

    dotnet tool install -g ilspycmd

If it isn't installed, `is_available()` returns False and the app falls
back to offering the raw package for download with a clear explanation,
instead of failing.

Decompilation happens one assembly at a time, triggered by the user
clicking a specific .dll in the viewer (see app.py's /decompile route) —
nothing here runs automatically for a whole package.
"""
import os
import shutil
import subprocess

_health_cache = {"checked": False, "healthy": None, "error": None}


def is_available() -> bool:
    return shutil.which("ilspycmd") is not None


def check_runtime_health(force: bool = False) -> tuple:
    """
    Runs a trivial ilspycmd invocation to confirm the .NET runtime can even
    start on this machine. Memoized process-wide after the first call (success
    or failure) so repeated clicks on different DLLs don't each re-probe a
    runtime that's already known to be broken — they get the same clear
    answer instantly instead.

    Returns (healthy: bool, error: str | None).
    """
    if not force and _health_cache["checked"]:
        return _health_cache["healthy"], _health_cache["error"]

    try:
        result = subprocess.run(
            ["ilspycmd", "--version"], capture_output=True, text=True, timeout=30,
        )
        if result.returncode != 0:
            error = (result.stderr or result.stdout or "unknown error").strip()
            healthy = False
        else:
            error = None
            healthy = True
    except subprocess.TimeoutExpired:
        healthy, error = False, "ilspycmd --version timed out after 30s."
    except OSError as e:
        healthy, error = False, str(e)

    _health_cache.update(checked=True, healthy=healthy, error=error)
    return healthy, error


def decompile_assembly(dll_path: str, out_dir: str) -> tuple:
    """
    Decompiles one assembly into `out_dir`. Tries project mode first (one .cs
    file per type, closest to real source layout); falls back to a single
    combined .cs file if project mode isn't supported for that assembly.

    Returns (success: bool, message: str).
    """
    os.makedirs(out_dir, exist_ok=True)

    project_result = subprocess.run(
        ["ilspycmd", dll_path, "-p", "-o", out_dir],
        capture_output=True, text=True, timeout=180,
    )
    if project_result.returncode == 0:
        return True, "decompiled (project mode)"

    single_file = os.path.join(out_dir, os.path.basename(dll_path) + ".decompiled.cs")
    single_result = subprocess.run(
        ["ilspycmd", dll_path, "-o", single_file],
        capture_output=True, text=True, timeout=180,
    )
    if single_result.returncode == 0:
        return True, "decompiled (single file)"

    error = (single_result.stderr or project_result.stderr or "unknown ilspycmd error").strip()
    return False, error
