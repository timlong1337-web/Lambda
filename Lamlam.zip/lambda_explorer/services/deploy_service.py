"""
Turns an edited file back into a deployable Lambda package.

Two paths:
- Plain text (a .py file, or any non-compiled file in a .NET package):
  the edited content replaces that file, everything else is re-zipped
  unchanged.
- A decompiled C# file (something under '<assembly>.dll.decompiled/'):
  the edit is written into a scratch copy of the decompiled project,
  which is then rebuilt with `dotnet build`. If that succeeds, the
  resulting .dll replaces the original assembly at its original path;
  everything else is re-zipped unchanged. If it fails, nothing is staged
  and the build output is returned so the person can see exactly why.

Nothing in this module talks to AWS — see LambdaService.update_function_code
for the actual deploy call, which only ever runs after the app's own
confirmation gates in app.py.
"""
import difflib
import io
import os
import shutil
import subprocess
import tempfile
import zipfile

DECOMPILED_SUFFIX = ".decompiled"


class DeployError(Exception):
    pass


def find_owning_dll(path: str) -> str:
    """
    'lib/MyFunction.dll.decompiled/MyNamespace/Handler.cs' -> 'lib/MyFunction.dll'.
    Returns None if `path` isn't inside a decompiled folder.
    """
    parts = path.split("/")
    for i, part in enumerate(parts):
        if part.endswith(DECOMPILED_SUFFIX):
            return "/".join(parts[:i] + [part[: -len(DECOMPILED_SUFFIX)]])
    return None


def sub_path_within_decompiled(path: str, dll_rel: str) -> str:
    """The part of `path` after '<dll_rel>.decompiled/' — where the edited
    file actually lives inside the decompiled project directory."""
    prefix = dll_rel + DECOMPILED_SUFFIX + "/"
    if not path.startswith(prefix):
        raise ValueError("path is not inside the decompiled folder for that dll")
    return path[len(prefix):]


def needs_compile(kind: str, path: str) -> bool:
    return kind == "dotnet" and path.endswith(".cs") and find_owning_dll(path) is not None


def build_diff(original: str, edited: str, path: str) -> str:
    return "".join(difflib.unified_diff(
        original.splitlines(keepends=True),
        edited.splitlines(keepends=True),
        fromfile=path + " (currently deployed)",
        tofile=path + " (edited)",
    ))


def find_csproj(decompiled_dir: str) -> str:
    for f in sorted(os.listdir(decompiled_dir)):
        if f.endswith(".csproj"):
            return os.path.join(decompiled_dir, f)
    for dirpath, _, filenames in os.walk(decompiled_dir):
        for f in sorted(filenames):
            if f.endswith(".csproj"):
                return os.path.join(dirpath, f)
    return None


def compile_dotnet_project(decompiled_dir: str, timeout: int = 180) -> tuple:
    """
    Runs `dotnet build` against the decompiled project (which ilspycmd's
    project mode generates alongside the .cs files). Returns
    (success: bool, output_dll_path: str | None, build_log: str).
    """
    if shutil.which("dotnet") is None:
        return False, None, (
            "The .NET SDK ('dotnet') isn't available on this host, so edited C# "
            "can't be rebuilt. Install it from https://dotnet.microsoft.com/download."
        )

    csproj = find_csproj(decompiled_dir)
    if not csproj:
        return False, None, "No .csproj found in the decompiled output — can't rebuild this assembly."

    out_dir = tempfile.mkdtemp(prefix="rebuilt_")
    try:
        result = subprocess.run(
            ["dotnet", "build", csproj, "-c", "Release", "-o", out_dir, "--nologo"],
            capture_output=True, text=True, timeout=timeout,
        )
    except subprocess.TimeoutExpired:
        return False, None, f"dotnet build timed out after {timeout}s."
    except OSError as e:
        return False, None, f"Couldn't run 'dotnet build': {e}"

    log = ((result.stdout or "") + "\n" + (result.stderr or "")).strip()
    if result.returncode != 0:
        return False, None, log or "dotnet build failed with no output."

    assembly_name = os.path.splitext(os.path.basename(csproj))[0]
    candidate = os.path.join(out_dir, assembly_name + ".dll")
    if not os.path.isfile(candidate):
        dlls = [f for f in os.listdir(out_dir) if f.endswith(".dll")]
        if not dlls:
            return False, None, log + "\n\n(Build reported success but no .dll was produced.)"
        candidate = os.path.join(out_dir, dlls[0])

    return True, candidate, log


def rebuild_zip(root: str, overrides: dict) -> bytes:
    """
    Zips everything under `root` for deployment, skipping any
    '<name>.decompiled' folders (those are decompiler scratch output
    grafted in for browsing — never part of the real deployment package).
    `overrides` is a {rel_path: bytes} map applied in place of whatever's
    on disk at those paths, without touching the files on disk.
    """
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        written = set()
        for dirpath, dirnames, filenames in os.walk(root):
            dirnames[:] = [d for d in dirnames if not d.endswith(DECOMPILED_SUFFIX)]
            for f in filenames:
                full = os.path.join(dirpath, f)
                rel = os.path.relpath(full, root)
                if rel in overrides:
                    zf.writestr(rel, overrides[rel])
                else:
                    zf.write(full, rel)
                written.add(rel)
        for rel, data in overrides.items():
            if rel not in written:
                zf.writestr(rel, data)
    return buf.getvalue()
