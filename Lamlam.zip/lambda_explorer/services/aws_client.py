"""
Thin wrapper around boto3 session creation + credential verification.

Credentials are never written to disk here. The caller is responsible for
where the resulting boto3.Session lives (this app keeps it in a server-side
session store — see app.py).
"""
import boto3
from botocore.exceptions import ClientError, NoCredentialsError, EndpointConnectionError


class CredentialError(Exception):
    """Raised when the supplied AWS credentials can't be used."""
    pass


def build_session(access_key: str, secret_key: str, region: str, session_token: str = None) -> boto3.session.Session:
    if not access_key or not secret_key or not region:
        raise CredentialError("Access key, secret key, and region are all required.")
    return boto3.session.Session(
        aws_access_key_id=access_key.strip(),
        aws_secret_access_key=secret_key.strip(),
        aws_session_token=(session_token.strip() if session_token else None),
        region_name=region.strip(),
    )


def verify_and_identify(session: boto3.session.Session) -> dict:
    """
    Calls STS GetCallerIdentity to confirm the credentials actually work
    before we let the user into the dashboard. Returns account/user info
    for display, or raises CredentialError with a human-readable reason.
    """
    try:
        sts = session.client("sts")
        identity = sts.get_caller_identity()
        return {
            "account": identity.get("Account"),
            "arn": identity.get("Arn"),
            "user_id": identity.get("UserId"),
        }
    except NoCredentialsError:
        raise CredentialError("No credentials were provided.")
    except EndpointConnectionError:
        raise CredentialError("Couldn't reach AWS. Check the region and your network connection.")
    except ClientError as e:
        code = e.response.get("Error", {}).get("Code", "Unknown")
        message = e.response.get("Error", {}).get("Message", str(e))
        if code in ("InvalidClientTokenId", "SignatureDoesNotMatch", "AccessDenied"):
            raise CredentialError("AWS rejected these credentials: " + message)
        raise CredentialError(f"AWS error ({code}): {message}")
