"""
Everything to do with turning a downloaded Lambda deployment package into
something browsable: unzip it, build a file tree, and syntax-highlight
individual files with Pygments (server-side, so no CDN dependency).
"""
import io
import os
import zipfile
import tempfile

from pygments import highlight
from pygments.lexers import get_lexer_by_name, guess_lexer_for_filename
from pygments.lexers.special import TextLexer
from pygments.formatters import HtmlFormatter
from pygments.util import ClassNotFound

PYGMENTS_STYLE = "monokai"

# Files/dirs that are noise in almost every deployment package — vendored
# dependency trees, native binaries, bytecode caches, etc. Hidden from the
# tree by default but not deleted, so nothing is actually lost.
NOISE_DIR_NAMES = {"__pycache__", ".dist-info", ".egg-info"}


def classify_runtime(runtime: str) -> str:
    """Buckets an AWS runtime string into 'python', 'dotnet', or 'other'."""
    if not runtime:
        return "other"
    r = runtime.lower()
    if r.startswith("python"):
        return "python"
    if r.startswith("dotnet"):
        return "dotnet"
    return "other"


def extract_zip(zip_bytes: bytes) -> str:
    """Extracts a deployment package into a fresh temp dir, returns its path."""
    out_dir = tempfile.mkdtemp(prefix="lambda_pkg_")
    with zipfile.ZipFile(io.BytesIO(zip_bytes)) as zf:
        zf.extractall(out_dir)
    return out_dir


def build_tree(root: str, path_prefix: str = "") -> dict:
    """
    Builds a nested dict describing the directory structure under `root`,
    suitable for json.dumps and rendering client-side as a collapsible tree.

    `path_prefix`, if given, is prepended to every reported path — used when
    grafting a decompiled assembly's output (its own separate temp dir) into
    the tree at the location of the .dll it came from, so paths line up with
    where that folder is actually reachable within the package root (see
    app.py's /decompile route).

    Shape: {"name": str, "type": "dir"|"file", "path": <relpath>, "children": [...]}
    """
    def walk(abs_path, rel_path):
        name = os.path.basename(abs_path) or rel_path
        if os.path.isdir(abs_path):
            children = []
            try:
                entries = sorted(os.listdir(abs_path), key=str.lower)
            except OSError:
                entries = []
            for entry in entries:
                if entry in NOISE_DIR_NAMES or entry.startswith("."):
                    continue
                child_abs = os.path.join(abs_path, entry)
                child_rel = os.path.join(rel_path, entry) if rel_path else entry
                children.append(walk(child_abs, child_rel))
            # Directories with no visible children are dropped so the tree
            # doesn't show empty noise folders.
            return {"name": name, "type": "dir", "path": rel_path, "children": children}
        else:
            return {"name": name, "type": "file", "path": rel_path, "children": None}

    root_node = walk(root, path_prefix)
    if not path_prefix:
        root_node["name"] = "/"
    return root_node


def find_files(root: str, extensions) -> list:
    """
    Returns relative paths of all files under root matching the given
    extensions. followlinks=True because a .NET package's browsable root is
    two symlinked folders (raw package + decompiled source, see
    app._merge_dirs) — without it, os.walk refuses to descend into either.
    """
    matches = []
    for dirpath, dirnames, filenames in os.walk(root, followlinks=True):
        dirnames[:] = [d for d in dirnames if d not in NOISE_DIR_NAMES and not d.startswith(".")]
        for f in filenames:
            if any(f.endswith(ext) for ext in extensions):
                full = os.path.join(dirpath, f)
                matches.append(os.path.relpath(full, root))
    return sorted(matches)


COMMON_ENTRY_NAMES = ("lambda_function.py", "app.py", "handler.py", "main.py", "index.py")


def pick_default_file(paths: list, handler: str = None) -> str:
    """
    Chooses which file to open by default when a function page first loads.
    Preference order: (1) the file the configured Handler actually points
    to, if we can resolve it, (2) a conventional entry-point filename,
    (3) the shallowest file (fewest path separators — a file sitting in the
    package root beats one buried three folders deep), alphabetical last.
    """
    if not paths:
        return None

    if handler and "." in handler:
        module_path = handler.rsplit(".", 1)[0].replace(".", "/") + ".py"
        for p in paths:
            if p == module_path or p.endswith("/" + module_path):
                return p

    by_basename = {os.path.basename(p): p for p in paths}
    for name in COMMON_ENTRY_NAMES:
        if name in by_basename:
            return by_basename[name]

    return sorted(paths, key=lambda p: (p.count("/"), p))[0]


def resolve_safe_path(root: str, rel_path: str) -> str:
    """Shared traversal guard used by every file-access helper below."""
    abs_root = os.path.abspath(root)
    abs_path = os.path.abspath(os.path.join(root, rel_path))
    if not abs_path.startswith(abs_root):
        raise ValueError("Invalid path.")
    if not os.path.isfile(abs_path):
        raise FileNotFoundError(rel_path)
    return abs_path


def read_text_file(root: str, rel_path: str, max_bytes: int = 2_000_000) -> str:
    """Safely reads a file within root, guarding against path traversal."""
    abs_path = resolve_safe_path(root, rel_path)
    size = os.path.getsize(abs_path)
    with open(abs_path, "rb") as fh:
        data = fh.read(max_bytes)
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError:
        return "" if size else ""  # binary file — caller should check is_probably_text first
    if size > max_bytes:
        text += "\n\n# ... truncated, file too large to display in full ..."
    return text


def read_file_bytes(root: str, rel_path: str) -> bytes:
    """Reads a file's raw bytes, exactly as stored — used for file downloads."""
    abs_path = resolve_safe_path(root, rel_path)
    with open(abs_path, "rb") as fh:
        return fh.read()


def is_probably_text(root: str, rel_path: str) -> bool:
    abs_path = os.path.join(root, rel_path)
    try:
        with open(abs_path, "rb") as fh:
            chunk = fh.read(4096)
        if b"\x00" in chunk:
            return False
        return True
    except OSError:
        return False


def highlight_code(code: str, filename: str = None, language: str = None) -> str:
    """Returns an HTML fragment (Pygments <div class="codehilite">...) for `code`."""
    lexer = None
    try:
        if language:
            lexer = get_lexer_by_name(language)
        elif filename:
            lexer = guess_lexer_for_filename(filename, code)
    except ClassNotFound:
        lexer = None
    if lexer is None:
        lexer = TextLexer()
    formatter = HtmlFormatter(linenos="table", cssclass="codehilite", style=PYGMENTS_STYLE)
    return highlight(code, lexer, formatter)


def pygments_css() -> str:
    return HtmlFormatter(style=PYGMENTS_STYLE).get_style_defs(".codehilite")
