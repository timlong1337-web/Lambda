"""
Optional AI-assisted review for whichever file is open in the source
viewer: a plain-English summary of what it does, plus a best-effort
security pass. This is a fast first read, not a substitute for a real audit.

Two providers, picked on the connect page:
- DeepSeek — a plain REST call via `requests` (already a hard dependency
  of this app), so it needs no extra package installed.
- Anthropic — via the official `anthropic` Python package, same as before.
"""
import json
import os

import requests

try:
    import anthropic
except ImportError:  # the app still runs without this installed — see provider_available()
    anthropic = None

PROVIDERS = ("deepseek", "anthropic")

DEEPSEEK_MODEL = os.environ.get("DEEPSEEK_MODEL", "deepseek-chat")
DEEPSEEK_API_URL = "https://api.deepseek.com/chat/completions"
ANTHROPIC_MODEL = os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-5")

MAX_CHARS = 60_000  # keep a single review to a sane token budget

SYSTEM_PROMPT = """You are a careful application security reviewer looking at one file from an AWS Lambda function's deployment package (it may be original source or decompiled — decompiled code can have generic names and lost comments; review the logic itself).

Respond with ONLY a JSON object, no markdown fences, no prose outside the JSON, in exactly this shape:
{
  "summary": "2-4 sentence plain-English explanation of what this file does",
  "vulnerabilities": [
    {"title": "short name", "severity": "low|medium|high|critical", "description": "what the issue is, and where in the file", "recommendation": "how to fix it"}
  ],
  "notes": "anything else worth flagging that isn't a security issue, or empty string"
}

If you find no plausible vulnerabilities, return an empty vulnerabilities array — don't invent issues just to have something to report. Be specific and reference the actual code rather than giving generic advice."""


class ScanError(Exception):
    pass


def provider_available(provider: str) -> bool:
    """Whether the *library* needed for this provider is present — separate
    from whether an API key is configured, which is checked at call time."""
    if provider == "deepseek":
        return True  # just needs an API key; the HTTP call uses `requests`
    if provider == "anthropic":
        return anthropic is not None
    return False


def scan_code(provider: str, api_key: str, code: str, filename: str, function_name: str) -> dict:
    if provider not in PROVIDERS:
        raise ScanError("No AI provider selected. Choose one on the connect page.")
    if not api_key:
        env_var = "DEEPSEEK_API_KEY" if provider == "deepseek" else "ANTHROPIC_API_KEY"
        raise ScanError(
            f"No API key configured for {provider}. Add one on the connect page, "
            f"or set {env_var} in the environment this app runs in."
        )

    trimmed = code
    if len(code) > MAX_CHARS:
        trimmed = code[:MAX_CHARS] + "\n\n# ... truncated for review, the file is larger than shown ..."
    user_content = f"File: {filename}\nFrom Lambda function: {function_name}\n\n```\n{trimmed}\n```"

    if provider == "deepseek":
        text = _call_deepseek(api_key, user_content)
    else:
        text = _call_anthropic(api_key, user_content)

    return _parse_response(text)


def _call_deepseek(api_key: str, user_content: str) -> str:
    try:
        resp = requests.post(
            DEEPSEEK_API_URL,
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
            json={
                "model": DEEPSEEK_MODEL,
                "messages": [
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": user_content},
                ],
                "response_format": {"type": "json_object"},
                "max_tokens": 2000,
                "stream": False,
            },
            timeout=90,
        )
    except requests.exceptions.RequestException as e:
        raise ScanError(f"Couldn't reach the DeepSeek API: {e}")

    if resp.status_code == 401:
        raise ScanError("DeepSeek rejected that API key.")
    if resp.status_code != 200:
        raise ScanError(f"DeepSeek API error ({resp.status_code}): {_extract_http_error(resp)}")

    try:
        data = resp.json()
        return data["choices"][0]["message"]["content"]
    except (KeyError, IndexError, ValueError) as e:
        raise ScanError(f"Unexpected response from DeepSeek: {e}")


def _extract_http_error(resp) -> str:
    try:
        data = resp.json()
        return data.get("error", {}).get("message", resp.text[:200])
    except ValueError:
        return resp.text[:200]


def _call_anthropic(api_key: str, user_content: str) -> str:
    if anthropic is None:
        raise ScanError(
            "The 'anthropic' package isn't installed. Run: pip install anthropic — "
            "or switch the provider to DeepSeek on the connect page, which needs no extra package."
        )
    client = anthropic.Anthropic(api_key=api_key)
    try:
        resp = client.messages.create(
            model=ANTHROPIC_MODEL,
            max_tokens=2000,
            system=SYSTEM_PROMPT,
            messages=[{"role": "user", "content": user_content}],
        )
    except anthropic.AuthenticationError:
        raise ScanError("Anthropic rejected that API key.")
    except anthropic.APIStatusError as e:
        raise ScanError(f"Anthropic API error ({e.status_code}): {getattr(e, 'message', str(e))}")
    except Exception as e:
        raise ScanError(f"Couldn't reach the Anthropic API: {e}")

    return "".join(block.text for block in resp.content if getattr(block, "type", None) == "text")


def _parse_response(text: str) -> dict:
    cleaned = text.strip()
    if cleaned.startswith("```"):
        cleaned = cleaned.strip("`")
        if cleaned.lower().startswith("json"):
            cleaned = cleaned[4:]
        cleaned = cleaned.strip()
    try:
        data = json.loads(cleaned)
    except json.JSONDecodeError:
        # The model didn't give us clean JSON — still show something useful
        # rather than a bare error.
        return {"summary": text.strip(), "vulnerabilities": [], "notes": ""}

    data.setdefault("summary", "")
    data.setdefault("vulnerabilities", [])
    data.setdefault("notes", "")
    return data
