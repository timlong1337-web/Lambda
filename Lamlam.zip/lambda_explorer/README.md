# Lambda Explorer

A Flask app that connects to an AWS account with an access key / secret key,
lists every Lambda function, and lets you read the source straight from the
browser:

- **Python functions** — the deployment package is downloaded and unzipped,
  and every file is browsable in a VS Code-style tree + syntax-highlighted
  panel.
- **C# / .NET functions** — the package is downloaded and browsable
  immediately, with `.dll` files shown right in the tree. Nothing gets
  decompiled until you click a specific one — that runs
  [ILSpy](https://github.com/icsharpcode/ILSpy) against just that assembly
  and expands it into `.cs` source in place, leaving every other DLL in the
  package untouched.
- **Container-image functions** — flagged as such, with the image URI shown
  (there's no zip package to open in that case).

The dashboard table sorts by clicking any of the **Function**, **Last
modified**, or **Last invoked** column headers — click again to flip the
direction. Name and last-modified sort instantly (that data's already on
the page); last-invoked is fetched lazily the first time you sort by it
(one lightweight CloudWatch Logs call per function, not the full log
history) and cached in the page after that, so switching direction again
doesn't refetch.

### Creating a new function

The **+ Create function** button on the dashboard opens a dialog — a real
modal, not a browser `alert()`, since an alert can't hold form fields —
with a name, a runtime dropdown, a handler field, an execution role field,
and two tabs: **Write code** (a syntax-highlighted editor, Python-aware,
for pasting or typing a quick single-file function) or **Upload file**
(pick a single source file, which gets zipped automatically to match your
handler, or a pre-built `.zip`, used as-is). Creating succeeds, you land
straight on that function's page, already browsable.

A few things worth knowing:

- **Lambda requires an existing IAM execution role** for every function —
  this tool doesn't create one for you. Paste in the ARN of a role that
  already exists (Lambda's console can create a basic one for you if you
  don't have one, or `aws iam create-role` / your usual infra-as-code
  tooling). See the IAM policy note below — the identity running this app
  also needs `iam:PassRole` for whatever role you paste in, which is easy
  to forget and shows up as a separate `AccessDenied` even once
  `CreateFunction` itself is allowed.
- **The runtime dropdown is a curated list, not a live query against
  AWS** — Lambda doesn't expose a "list valid runtimes" API, and the
  actual list changes over time as AWS adds and deprecates runtimes (two
  new preview runtimes shipped the same week this feature was built). If
  your runtime isn't listed, pick **Other — type manually…** and enter
  the exact identifier; Lambda will reject an invalid one immediately
  with a clear error rather than silently misbehaving.
- **The code editor's live syntax highlighting comes from
  [CodeMirror](https://codemirror.net/), loaded from a CDN** — the one
  external CDN dependency in this app besides the fonts on the login/nav
  chrome. It needs the browser (not the machine running the Flask process)
  to reach `cdnjs.cloudflare.com`. If it can't, the "Write code" tab
  quietly falls back to a plain, fully functional textarea — you lose the
  highlighting, not the feature.
- A single source file uploaded (or typed) is inherently limited to
  Python's standard library — there's no way to bundle third-party
  dependencies through a single textarea or file. If your function needs
  packages, build a proper `.zip` with its dependencies included and use
  the upload tab with that instead.
- Direct zip uploads are capped at Lambda's own **50 MB** limit; anything
  larger needs to go through S3, which this tool doesn't support.

Every function page has a **📜 View logs** button, regardless of runtime —
it pulls the most recent CloudWatch Logs events across that function's
last few active log streams (merged and sorted, newest last) and opens
them in a panel with a **Refresh** button. `START`/`END`/`REPORT` lines are
dimmed and anything that looks like an error or traceback is highlighted,
so a burst of `print()`/`console.log` output is easy to scan.

Every function page also has one-click **download the raw package** and
(for .NET) **download the decompiled source as a zip** — that one bundles
up whatever you've decompiled so far in the session, not the whole
package. Inside the code viewer, whichever file is open gets its own
**Download file** button, a **✦ Scan with AI** button that sends just
that file to Claude for a plain-English explanation of what it does plus
a best-effort vulnerability review, and an **✎ Edit** button that lets you
change the file and deploy it back to the live function — see below.

### Editing and deploying code back to AWS

Click **✎ Edit** on an open file to turn the code panel into a textarea.
For a `.py` file (or any plain-text file), your edit goes straight into a
diff. For a decompiled `.cs` file, clicking **🛠 Build & Review Deploy**
first recompiles it with `dotnet build` against the project ilspycmd
generated when you decompiled it — if that fails, you get the compiler
output and nothing is staged; if it succeeds, the freshly built `.dll`
replaces the original assembly at its original path in the package,
and everything else in the deployment package is left untouched either way.

Deploying is behind four separate gates, none of which happen
automatically: (1) click Edit, (2) click Build & Review Deploy — this
only compiles/diffs, it never calls AWS, (3) type the function's exact
name into a confirmation box that shows the diff and an explicit warning,
(4) click Deploy, which also asks a native "are you sure" before it
actually calls `UpdateFunctionCode`. After a successful deploy, a
**⏪ Rollback** button appears that redeploys exactly what was live
immediately beforehand — good for one level of "undo" for the rest of
that session, not a substitute for real version control.

Recompiling decompiled C# is inherently best-effort: ilspycmd's project
mode tries to reconstruct a buildable project, including package
references, but that doesn't always succeed cleanly for every assembly —
see the troubleshooting note near the bottom of this file if a build fails
for reasons that don't look like your edit.

## Setup

```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### C# decompilation prerequisite

Decompiling `.dll` files requires **ilspycmd**, the command-line tool for
ILSpy. It's a .NET global tool, not a Python package:

```bash
# requires the .NET SDK: https://dotnet.microsoft.com/download
dotnet tool install -g ilspycmd
```

Make sure `ilspycmd` is on the `PATH` of whatever shell runs `python app.py`.
If it isn't installed, the app still works — C# functions just show a
banner explaining that, and clicking a `.dll` reports the same thing
inline instead of trying, so you can download the raw package instead.

Recompiling an edited `.cs` file additionally needs the full **.NET SDK**
(`dotnet build`, not just the runtime `ilspycmd` needs to run) — the same
install covers both. If it's missing, "Build & Review Deploy" reports
that clearly instead of failing partway through.

### AI review prerequisite (optional)

"✦ Scan with AI" supports two providers, picked on the connect page:

- **DeepSeek** (the default) — a plain REST call, no extra package needed.
  ```bash
  export DEEPSEEK_API_KEY=sk-...
  ```
- **Anthropic (Claude)** — needs the `anthropic` package, already in
  `requirements.txt`.
  ```bash
  export ANTHROPIC_API_KEY=sk-ant-...
  ```

Either env var works, or paste the matching key into the optional field on
the connect page instead — that field is only there for when you'd rather
not set an environment variable. The button always appears regardless of
what's configured; clicking it explains exactly what's missing (no key, or
for Anthropic, the package not being installed) instead of just not
showing up. Nothing is sent anywhere until you click the button on a
specific file, and only that one file's contents are sent, to whichever
provider you picked.

## Running it

```bash
python app.py
```

Then open `http://127.0.0.1:5050`, paste in an access key / secret key
(and a session token if you're using temporary STS credentials) and a
region, and connect.

The IAM identity needs, at minimum:

```json
{
  "Effect": "Allow",
  "Action": [
    "lambda:ListFunctions",
    "lambda:GetFunction",
    "lambda:UpdateFunctionCode",
    "lambda:CreateFunction",
    "logs:DescribeLogStreams",
    "logs:GetLogEvents"
  ],
  "Resource": "*"
}
```

`lambda:CreateFunction` alone isn't enough for **+ Create function** to
work — Lambda also requires `iam:PassRole` on whatever execution role you
paste into the dialog, since you're effectively handing that role to a
service. That one's scoped to the specific role, not `*`:

```json
{
  "Effect": "Allow",
  "Action": "iam:PassRole",
  "Resource": "arn:aws:iam::<account-id>:role/<the-role-you-plan-to-use>"
}
```

Leave out `lambda:UpdateFunctionCode` / `lambda:CreateFunction` (and the
matching `iam:PassRole`) if you only want read/browse access — the rest of
the app still works without them; only the Deploy and Create-function
steps need them, and you'll get a normal AWS permission-denied error at
that step instead of partway through something destructive.

## Security notes — read before pointing this at a real account

This tool is built the way it was asked for: raw access-key/secret-key
login. A few things worth knowing about that trade-off:

- **Credentials are kept server-side**, in a `Flask-Session` filesystem
  store under `.flask_session/` next to the app — not in a browser cookie
  (a default Flask session cookie is only *signed*, not encrypted, so a
  secret key would be readable by anyone who got the cookie). Even so,
  treat `.flask_session/` as sensitive: it's plaintext on disk for as long
  as the session lives.
- **Long-lived access keys are the highest-risk form of AWS credential.**
  If you can, generate temporary credentials instead (`aws sts
  assume-role` / `get-session-token`) and paste those in along with the
  session token field — same login form, much shorter blast radius if
  they leak.
- **This app is meant to run locally or on a trusted internal host**, not
  be exposed on the open internet — anyone who can reach it can reach
  everything those AWS credentials can reach, plus the full decompiled
  source of your C# functions. There's no app-level login in front of the
  AWS login step; put it behind a VPN or add one if that's not true for
  your setup.
- Downloaded packages are cached **in server memory** for the life of the
  process (keyed to each function's code hash, so a redeploy is picked up
  automatically) and extracted to the OS temp directory. Decompiled output
  is cached the same way, per assembly, so re-clicking a `.dll` you've
  already decompiled doesn't re-run `ilspycmd`. Restarting the app clears
  everything; temp directories are not auto-deleted, so periodically clear
  your temp folder if you're doing this a lot.
- **AI review sends the open file's source to whichever provider you
  picked** (DeepSeek or Anthropic). That's the whole point of the feature,
  but it's worth being deliberate about it — don't scan files with
  hardcoded secrets or anything else you wouldn't want leaving the
  machine, and treat the reviews as a fast first pass, not a finding you'd
  cite in an audit. Results are cached in the same server memory as
  everything else, keyed by function + file + code hash + provider, so
  reopening a review (or switching providers and reopening it again)
  doesn't unnecessarily re-spend API tokens.
- **Deploying overwrites the live `$LATEST` version of the function
  immediately** — there's no staging environment or approval workflow here,
  just the in-app confirmation gates described above. The one-click
  rollback only remembers the single version that was live right before
  your most recent deploy through this app, only for as long as the
  process keeps running, and is overwritten the next time you deploy — it
  is not a replacement for keeping your own record of what's supposed to
  be deployed (a Git history, a published Lambda version, a CI pipeline).
  If the function you're editing has other people actively deploying to
  it too, this app has no way to know that.

## Editing safety details

Edit mode adds a few guardrails beyond the four deploy gates described
above: switching to a different file, or clicking a `.dll` to decompile it,
asks to confirm first if you have unsaved edits open. So does closing the
tab or navigating away entirely (via the browser's own "leave site?"
prompt) — both because a stray click shouldn't silently discard work.
After a successful deploy, the code panel deliberately shows a plain
"deployed — reload to browse the new code" placeholder rather than quietly
leaving the pre-edit version on screen, since that old syntax-highlighted
view is stale the moment the deploy succeeds.

## How the C# decompilation works

Nothing decompiles until you click a `.dll` in the tree. That click runs
`ilspycmd` against just that one assembly — project mode first (`-p`, one
`.cs` file per type — the closest thing to real source layout), falling
back to a single combined `.cs` file if project mode fails for that
particular assembly. The result expands in place under that `.dll`'s row
in the tree, and a small "Decompile activity" log at the top of the page
records every attempt, success or failure, as you go.

A broken `.dll` doesn't affect any others — each one is independent, and
a failure just marks that row and moves on. The one exception is if the
.NET runtime itself can't start at all (see the troubleshooting section
below): the app detects that on the first click and shows one clear
banner instead of letting you discover it failure by failure.

Decompiled output is best-effort — it's the same technique tools like
dnSpy and ILSpy's GUI use, and works well for typical managed Lambda
handlers, but variable names, comments, and some language constructs from
the original source are not recoverable from IL and won't come back
exactly as written.

### Troubleshooting: "GC heap initialization failed" / CoreCLR won't start

If clicking a `.dll` reports an error about the GC reserving a huge
amount of memory (something like `0x8007000E` and a mention of ~256 GiB),
that's not about that assembly at all — it means the .NET runtime can't
start as a process on this machine, full stop, and every other `.dll`
will fail the same way. To fix the underlying issue:

- Run `ilspycmd --version` (or just `dotnet --version`) directly in the
  same shell — if that alone throws the same error with no app involved,
  it confirms this is a machine-level problem, not this app.
- Check for a 32-bit `dotnet` shadowing the 64-bit one (`dotnet --info`
  shows the architecture); a 32-bit process can't reserve that much address
  space and fails immediately. Reinstall the tool once the right one is
  first on `PATH`: `dotnet tool uninstall -g ilspycmd && dotnet tool install -g ilspycmd`.
- Locked-down corporate machines, Windows Sandbox, and memory-limited
  VMs/containers sometimes cap a process's virtual address space via a job
  object — that produces exactly this error too. On Linux this often shows
  up as a `ulimit -v` restriction or a container/cgroup memory limit; on a
  sandboxed runtime (gVisor and similar) that emulates `/proc`, neither may
  be adjustable from inside the container at all.
- As a workaround either way, capping the GC heap avoids the huge upfront
  reservation:
  ```
  export DOTNET_GCHeapHardLimit=0x10000000   # Linux/macOS
  setx DOTNET_GCHeapHardLimit 10000000       # Windows — open a new terminal after
  ```
  then start `python app.py` from that same shell so the decompiler
  subprocess inherits it. If the environment truly can't run CoreCLR at
  all (some sandboxes can't), download the raw package instead and run
  `ilspycmd` against it on a normal machine.

### Troubleshooting: "Build & Review Deploy" fails on an unmodified file

If rebuilding fails with errors that don't reference anything you
actually changed — missing types, unresolved namespaces, package version
mismatches — that's almost always ilspycmd's generated `.csproj` not
perfectly reconstructing the original project's references, not a problem
with your edit. Some things worth checking:

- Whether NuGet packages the project depends on can actually be restored
  from wherever `dotnet build` is running (network access, a configured
  NuGet feed, credentials for a private feed if the original build used
  one).
- Whether the decompiled project's target framework matches what's
  actually installed (`dotnet --list-sdks`) — ilspycmd infers this from
  the original assembly, but an unusual or preview target framework may
  not be installed on this machine.

This is a known limitation of recompiling decompiled code in general, not
something the app can fully paper over — if a particular assembly
consistently won't rebuild, editing it here isn't a good fit; the raw
package download plus your own build environment is the more reliable path.
